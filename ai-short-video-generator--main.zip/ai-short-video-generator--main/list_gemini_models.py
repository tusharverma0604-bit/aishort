import os
import sys
from google import genai

def main():
    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        print("No API key found")
        sys.exit(1)
        
    client = genai.Client(api_key=api_key)
    try:
        models = client.models.list_models()
        for m in models:
            print(f"- {m.name} (supports: {m.supported_actions})")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
