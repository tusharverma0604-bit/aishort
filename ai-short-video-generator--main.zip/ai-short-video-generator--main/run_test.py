import asyncio
import os
import json
from google import genai
from google.genai import types

class ViralClipCandidate(types.BaseModel):
    title: str
    reason: str
    score: int
    start_time: float
    end_time: float
    hook: str
    tags: list[str]
    mood: str
    youtube_title: str
    youtube_description: str

class ViralClipResponse(types.BaseModel):
    clips: list[ViralClipCandidate]

async def main():
    api_key = os.environ.get("GEMINI_API_KEY", os.environ.get("GOOGLE_API_KEY"))
    client = genai.Client(api_key=api_key)
    
    prompt = """
    Analyze this text and give me 2 viral clips.
    IMPORTANT JSON RULES:
    - Do NOT use newlines inside any JSON strings. Keep all descriptions and text on a single line.
    - Do NOT use unescaped double quotes inside strings. Use single quotes for dialogue or quotes.
    Text: "Welcome to modern wisdom. Today we discuss politics and AI. AI is very dangerous but also very cool. Thank you for watching."
    """
    
    try:
        response = client.models.generate_content(
            model="gemini-3.5-flash",
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                max_output_tokens=4096,
                response_schema=ViralClipResponse,
                safety_settings=[
                    types.SafetySetting(category="HARM_CATEGORY_HATE_SPEECH", threshold="BLOCK_NONE"),
                    types.SafetySetting(category="HARM_CATEGORY_HARASSMENT", threshold="BLOCK_NONE"),
                    types.SafetySetting(category="HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold="BLOCK_NONE"),
                    types.SafetySetting(category="HARM_CATEGORY_DANGEROUS_CONTENT", threshold="BLOCK_NONE"),
                ]
            )
        )
        print("--- RAW TEXT ---")
        print(response.text)
        print("----------------")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(main())
