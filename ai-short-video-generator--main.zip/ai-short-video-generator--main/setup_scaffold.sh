#!/bin/bash
mkdir -p backend/api/routes backend/models backend/services backend/pipeline/stages \
         services/download services/transcription services/llm/providers services/llm/prompts \
         services/video services/captions services/export \
         storage/uploads storage/projects storage/outputs storage/temp storage/cache \
         storage/thumbnails storage/transcripts storage/logs \
         config/caption_styles scripts tests/unit tests/integration tests/pipeline docs

touch backend/__init__.py backend/api/__init__.py backend/api/routes/__init__.py \
      backend/models/__init__.py backend/services/__init__.py backend/pipeline/__init__.py backend/pipeline/stages/__init__.py \
      services/__init__.py services/download/__init__.py services/transcription/__init__.py \
      services/llm/__init__.py services/llm/providers/__init__.py services/llm/prompts/__init__.py \
      services/video/__init__.py services/captions/__init__.py services/export/__init__.py \
      tests/__init__.py tests/unit/__init__.py tests/integration/__init__.py tests/pipeline/__init__.py

cp .env.example .env

echo "Scaffold setup complete!"
