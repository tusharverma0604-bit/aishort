from lightning_sdk import Studio
import sys
import os

files_to_sync = [
    "frontend/next.config.ts",
    "frontend/src/app/page.tsx",
    "frontend/src/components/SettingsPanel.tsx",
    "frontend/src/components/PipelineProgress.tsx",
    "frontend/src/components/SystemInfo.tsx",
    "frontend/src/lib/api.ts",
    "frontend/src/lib/types.ts",
    "frontend/src/app/layout.tsx",
    "frontend/src/app/settings/page.tsx",
    "frontend/src/app/settings/page.module.css",
    "backend/pipeline/orchestrator.py",
    "backend/config.py",
    "backend/config_manager.py",
    "backend/dependencies.py",
    "backend/models/project.py",
    "backend/api/routes/clips.py",
    "backend/api/routes/projects.py",
    "backend/api/routes/system.py",
    "backend/api/routes/youtube.py",
    "backend/main.py",
    "backend/services/video/auto_reframe.py",
    "backend/services/video/audio_mixer.py",
    "backend/services/video/face_detector.py",
    "backend/services/llm/providers/__init__.py",
    "backend/services/llm/providers/custom.py",
    "backend/services/llm/providers/omnirouter.py",
    "backend/services/llm/providers/gemini.py",
    "backend/services/llm/viral_analyzer.py",
    "backend/services/llm/prompts/viral_moments.txt",
    "backend/services/transcription/whisper_service.py",
    "backend/services/download/downloader.py",
    ".env",
    "start.sh"
]

try:
    print("Connecting to Studio...")
    studio = Studio(name="shortclips-ai", teamspace="deploy-model-project", user="riyazpatan000")
    # studio.start() # Studio is already running
    for file in files_to_sync:
        if os.path.exists(file):
            print(f"Uploading {file}...")
            studio.upload_file(file, file)
    print("All files synced successfully!")
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)
