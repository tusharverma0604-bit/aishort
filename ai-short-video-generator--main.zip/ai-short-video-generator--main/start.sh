#!/bin/bash
# ──────────────────────────────────────────────────────────────
# Short Video Generator — Clean Startup Script for Lightning AI
# Usage: bash start.sh
# ──────────────────────────────────────────────────────────────

set -e

echo "╔══════════════════════════════════════════════════════╗"
echo "║   Short Video Generator — Starting All Services     ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── Step 0: Ensure Node.js 24+ is active (sleep mode wakeup can revert PATH to Node 22.14 which causes silent native module exits in Next.js 16 and OmniRoute) ──
for node_dir in /system/conda/node/nvm/versions/node/* "$HOME/.nvm/versions/node/"* /usr/local/node/* /usr/local/*; do
    if [ -f "$node_dir/bin/node" ] && [ -x "$node_dir/bin/node" ]; then
        node_ver=$("$node_dir/bin/node" -v 2>/dev/null || echo "v0")
        if [[ "$node_ver" == v24* ]] || [[ "$node_ver" == v23* ]] || [[ "$node_ver" == v25* ]] || [[ "$node_ver" == v26* ]]; then
            export PATH="$node_dir/bin:$PATH"
            echo "🟢 Switched to compatible Node.js $node_ver ($node_dir/bin/node)"
            break
        fi
    fi
done
echo ""

# ── Step 1: Kill any zombie processes on our ports ──
echo "🧹 Cleaning up old processes..."
fuser -k -n tcp 8000 2>/dev/null || true
fuser -k -n tcp 8001 2>/dev/null || true
echo "   ✅ Old processes cleared"
echo ""

# ── Step 2: Start Backend API on port 8001 ──
echo "⚡ Starting Backend API on port 8001..."
cd /teamspace/studios/this_studio

# Ensure MediaPipe and OpenCV are installed so face detection runs on neural network/GPU instead of CPU fallback
python3 -c "import mediapipe as mp; mp.solutions.face_mesh" 2>/dev/null || {
    echo "📦 Installing MediaPipe & OpenCV for fast neural face tracking..."
    pip install -q "mediapipe==0.10.14" opencv-python-headless < /dev/null
    echo "   ✅ AI vision packages installed"
}

echo "📦 Installing backend requirements..."
pip install -q -r requirements.txt < /dev/null
echo "   ✅ Backend requirements installed"

nohup uvicorn backend.main:app --host 0.0.0.0 --port 8001 > /tmp/backend.log 2>&1 &
BACKEND_PID=$!

# Wait for backend to be fully ready (health check loop, max 120 seconds)
echo "   ⏳ Waiting for backend to start..."
BACKEND_READY=0
for attempt in $(seq 1 60); do
    if ! kill -0 $BACKEND_PID 2>/dev/null; then
        echo "   ❌ Backend process died — check /tmp/backend.log"
        break
    fi
    if curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8001/api/v1/system/health 2>/dev/null | grep -q 200; then
        BACKEND_READY=1
        break
    fi
    sleep 2
done

if [ "$BACKEND_READY" -eq 1 ]; then
    echo "   ✅ Backend API ready (PID: $BACKEND_PID)"
else
    echo "   ⚠️  Backend not yet responding — frontend will retry automatically"
fi
echo ""

# ── Step 3: Start Frontend on port 8000 ──
# Port 8000 is Lightning Studio's externally-exposed web port
echo "🌐 Starting Frontend on port 8000..."
cd /teamspace/studios/this_studio/frontend

# Ensure package.json has correct dev command with Turbopack for ultra-fast startup and lower memory usage
sed -i 's/"dev": "next dev.*"/"dev": "next dev --turbo -H 0.0.0.0 -p 8000"/g' package.json 2>/dev/null || true

# Ensure next.config.ts points to backend on IPv4 127.0.0.1:8001 to prevent Node.js IPv6 timeouts
sed -i "s/localhost:8001/127.0.0.1:8001/g; s/localhost:8000/127.0.0.1:8001/g" next.config.ts 2>/dev/null || true

# ── Sleep Mode Self-Healing: Verify Next.js, Types, and Workspace integrity ──
# 1. Clean up stray lockfiles in the root directory that confuse Next.js/Turbopack workspace root inference
rm -f /teamspace/studios/this_studio/package-lock.json /teamspace/studios/this_studio/package.json 2>/dev/null || true
rm -rf /teamspace/studios/this_studio/node_modules 2>/dev/null || true

# 2. Check for missing type definitions or corrupted SWC binaries (common after sleep mode)
if [ ! -d "node_modules" ] || [ ! -d "node_modules/@types/react" ] || ! node -e "require('next/dist/build/swc')" 2>/dev/null; then
    echo "🧹 Missing types or corrupted SWC binaries detected (sleep mode wakeup). Restoring clean packages..."
    rm -rf node_modules .next package-lock.json 2>/dev/null || true
    npm install --include=dev < /dev/null
    echo "   ✅ Clean packages installed"
fi

# Rebuild native addons in case Node.js version changed after sleep mode wakeup
npm rebuild < /dev/null >/dev/null 2>&1 || true

# Clean up stale or corrupted Next.js build cache from sleep mode
rm -rf .next

# Ensure port 8000 is 100% free right before starting in case anything respawned during npm install
fuser -k -n tcp 8000 2>/dev/null || true
lsof -ti :8000 2>/dev/null | xargs kill -9 2>/dev/null || true
sleep 1

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   🎬 All Services Starting!                         ║"
echo "║                                                     ║"
echo "║   Frontend:  port 8000 (click Globe icon to open)   ║"
echo "║   Backend:   port 8001 (API)                        ║"
echo "║                                                     ║"
echo "║   Logs:                                             ║"
echo "║     Backend:   tail -f /tmp/backend.log             ║"
echo "║     Frontend:  shown below ⬇                        ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Keep stdin indefinitely open using a named pipe (FIFO) so Next.js never receives EOF from web terminal subshell closure
rm -f /tmp/next_stdin 2>/dev/null || true
mkfifo /tmp/next_stdin 2>/dev/null || true
tail -f /dev/null > /tmp/next_stdin 2>/dev/null &
FIFO_PID=$!

# Run frontend in foreground connected to the infinite FIFO stream with automatic restart on temporary exits
while true; do
    npm run dev < /tmp/next_stdin || true
    echo ""
    echo "⚠️  Frontend exited. Restarting in 2 seconds..."
    sleep 2
done
kill -9 $FIFO_PID 2>/dev/null || true
