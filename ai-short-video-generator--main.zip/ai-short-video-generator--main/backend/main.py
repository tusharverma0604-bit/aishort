"""FastAPI application entry point."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.config import get_settings
from backend.exceptions import AppError
from backend.logging_config import setup_logging
from backend.services.job_queue import JobQueue
from backend.services.storage import StorageService

from backend.config_manager import ConfigManager

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(application: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan: initialize services on startup, clean up on shutdown."""
    settings = get_settings()
    setup_logging(settings.log_level)
    logger.info("Starting Short Video Generator API...")

    # Initialize services
    application.state.config = settings
    application.state.storage = StorageService(settings.storage_dir)
    
    config_manager = ConfigManager(settings.storage_dir)
    application.state.app_config_manager = config_manager

    job_queue = JobQueue(max_concurrent=1)
    application.state.job_queue = job_queue
    await job_queue.start()

    logger.info(
        "API ready — device=%s, whisper=%s, storage=%s",
        settings.resolved_device,
        settings.resolved_whisper_model,
        settings.storage_dir,
    )

    # Clean up orphaned projects (projects that were running when the server stopped)
    storage = application.state.storage
    try:
        from backend.models.project import ProjectStatus, StageStatus
        projects = await storage.list_projects()
        orphaned_count = 0
        for project in projects:
            if project.status not in (ProjectStatus.COMPLETED, ProjectStatus.FAILED, ProjectStatus.CANCELLED, ProjectStatus.PENDING):
                logger.info("Marking orphaned project %s as failed", project.id[:8])
                project.status = ProjectStatus.FAILED
                project.error = "Server was restarted while processing. Please retry."
                
                # Mark any running stage as failed too
                if hasattr(project, 'stages') and project.stages:
                    for stage in project.stages:
                        if stage.status in (StageStatus.RUNNING, StageStatus.PENDING):
                            stage.status = StageStatus.FAILED
                            stage.error = "Server restarted"
                
                await storage.update_project(project)
                orphaned_count += 1
        if orphaned_count > 0:
            logger.info("Cleaned up %d orphaned projects", orphaned_count)
    except Exception as e:
        logger.error(f"Failed to cleanup orphaned projects: {e}", exc_info=True)

    yield

    logger.info("Shutting down...")
    await job_queue.shutdown()


app = FastAPI(
    title="Short Video Generator",
    description="Convert long-form YouTube videos into viral short-form clips",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS for local and cloud studio frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "http://localhost:3001",
        "http://127.0.0.1:3001",
    ],
    allow_origin_regex=".*",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(AppError)
async def handle_app_error(request: Request, exc: AppError) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.message,
            "detail": exc.detail,
        },
    )


# Import and include routers
from backend.api.routes import clips, projects, status, system, youtube  # noqa: E402

app.include_router(system.router, prefix="/api/v1")
app.include_router(projects.router, prefix="/api/v1")
app.include_router(youtube.router, prefix="/api/v1/youtube", tags=["youtube"])
app.include_router(status.router, prefix="/api/v1")
app.include_router(clips.router, prefix="/api/v1")
