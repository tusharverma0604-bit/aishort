import json
import logging
import os
from pathlib import Path
from typing import List

from pydantic import BaseModel

logger = logging.getLogger(__name__)

class AppConfig(BaseModel):
    """Persistent application settings editable by the user."""
    # API Keys
    llm_provider: str = "gemini"  # "gemini" or "custom"
    gemini_api_keys: List[str] = []
    
    # Custom/Universal LLM Support
    custom_api_keys: List[str] = []
    custom_base_url: str = "https://api.openai.com/v1"
    custom_model: str = "gpt-4o"
    
    # YouTube Settings
    youtube_client_id: str = ""
    youtube_client_secret: str = ""
    
    # Defaults
    default_caption_style: str = "karaoke"
    default_reframe_mode: str = "smart_crop"
    default_viral_threshold: int = 70


class ConfigManager:
    """Manages reading and writing AppConfig to a JSON file."""
    
    def __init__(self, storage_dir: Path):
        self.storage_dir = storage_dir
        self.config_path = self.storage_dir / "app_config.json"
        
        # Ensure storage dir exists
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        # Load or create defaults
        self.config = self._load_config()

    def _load_config(self) -> AppConfig:
        """Load configuration from disk, or return default if it doesn't exist."""
        if not self.config_path.exists():
            return AppConfig()
            
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return AppConfig(**data)
        except Exception as e:
            logger.error(f"Failed to load app_config.json: {e}")
            return AppConfig()

    def get_config(self) -> AppConfig:
        """Get the current configuration."""
        return self.config

    def save_config(self, new_config: AppConfig) -> None:
        """Save the configuration to disk."""
        self.config = new_config
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                f.write(new_config.model_dump_json(indent=2))
        except Exception as e:
            logger.error(f"Failed to save app_config.json: {e}")
            raise
