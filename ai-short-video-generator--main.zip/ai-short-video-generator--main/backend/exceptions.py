class AppError(Exception):
    """Base application error."""
    def __init__(self, message: str, status_code: int = 500, detail: str | None = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.detail = detail

class ProjectNotFoundError(AppError):
    def __init__(self, message: str = "Project not found", detail: str | None = None):
        super().__init__(message, status_code=404, detail=detail)

class ProjectAlreadyExistsError(AppError):
    def __init__(self, message: str = "Project already exists", detail: str | None = None):
        super().__init__(message, status_code=409, detail=detail)

class DownloadError(AppError):
    def __init__(self, message: str = "Download error", detail: str | None = None):
        super().__init__(message, status_code=500, detail=detail)

class TranscriptionError(AppError):
    def __init__(self, message: str = "Transcription error", detail: str | None = None):
        super().__init__(message, status_code=500, detail=detail)

class LLMError(AppError):
    def __init__(self, message: str = "LLM error", detail: str | None = None):
        super().__init__(message, status_code=500, detail=detail)

class VideoProcessingError(AppError):
    def __init__(self, message: str = "Video processing error", detail: str | None = None):
        super().__init__(message, status_code=500, detail=detail)

class PipelineError(AppError):
    def __init__(self, message: str = "Pipeline error", detail: str | None = None):
        super().__init__(message, status_code=500, detail=detail)

class FFmpegError(AppError):
    def __init__(self, message: str = "FFmpeg error", detail: str | None = None):
        super().__init__(message, status_code=500, detail=detail)
