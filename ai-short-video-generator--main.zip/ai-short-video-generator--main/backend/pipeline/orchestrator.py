"""Pipeline orchestrator — wires all services into a sequential stage-based pipeline."""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from backend.config import Settings
from backend.models.project import (
    ProcessedClip,
    Project,
    ProjectStatus,
    StageStatus,
    TranscriptWord,
)
from backend.services.storage import StorageService
from backend.services.job_queue import JobQueue
from backend.services.download.downloader import DownloadService
from backend.services.download.audio_extractor import AudioExtractor
from backend.services.transcription.whisper_service import WhisperTranscriptionService
from backend.services.llm.providers import create_llm_provider
from backend.services.llm.viral_analyzer import ViralAnalyzer
from backend.services.video import AutoReframer, ClipCutter, FaceDetector
from backend.services.video.audio_mixer import AudioMixer
from backend.services.captions.style_loader import load_caption_style
from backend.services.captions.ass_generator import ASSGenerator
from backend.services.captions.burn_in import CaptionBurnIn
from backend.services.youtube_uploader import YouTubeUploader
from backend.pipeline.thumbnail import ThumbnailGenerator
from backend.exceptions import PipelineError

logger = logging.getLogger(__name__)


def _now() -> datetime:
    return datetime.now(timezone.utc)


class PipelineOrchestrator:
    """Orchestrates the full video-to-shorts pipeline.

    Pipeline stages:
    1. Download video (yt-dlp)
    2. Extract audio (FFmpeg → 16kHz WAV)
    3. Transcribe (faster-whisper)
    4. Analyze for viral moments (LLM)
    5. Cut clips (FFmpeg)
    6. Reframe to 9:16 (face detection + FFmpeg crop)
    7. Generate & burn captions (ASS + FFmpeg)
    8. Export final clips
    """

    def __init__(
        self,
        storage: StorageService,
        job_queue: JobQueue,
        settings: Settings,
        app_config: "AppConfig" = None,
    ) -> None:
        self.storage = storage
        self.job_queue = job_queue
        self.settings = settings
        
        # Dynamic LLM Provider Selection
        provider_name = app_config.llm_provider if app_config else "gemini"
        api_keys = []
        base_url = ""
        model_name = settings.llm_model
        
        if provider_name == "gemini":
            if app_config and app_config.gemini_api_keys:
                api_keys = app_config.gemini_api_keys
            elif settings.gemini_api_key:
                api_keys = [settings.gemini_api_key]
        elif provider_name == "custom":
            api_keys = app_config.custom_api_keys if app_config else []
            base_url = app_config.custom_base_url if app_config else ""
            model_name = app_config.custom_model if app_config else ""

        self.downloader = DownloadService(storage)
        self.audio_extractor = AudioExtractor(storage)
        self.transcriber = WhisperTranscriptionService(
            settings.resolved_whisper_model,
            settings.resolved_device,
            settings.resolved_compute_type,
        )
        self.llm_provider = create_llm_provider(
            provider_name,
            base_url,
            api_keys,
            model_name,
        )
        self.viral_analyzer = ViralAnalyzer(
            self.llm_provider,
            Path("backend/services/llm/prompts"),
        )
        self.clip_cutter = ClipCutter(settings.ffmpeg_threads)
        self._face_detector: FaceDetector | None = None
        self._auto_reframer: AutoReframer | None = None
        self._audio_mixer: AudioMixer | None = None
        self.ass_generator = ASSGenerator()
        self.caption_burn_in = CaptionBurnIn(settings.ffmpeg_threads)
        self.thumbnail_generator = ThumbnailGenerator()
        self.youtube_uploader = YouTubeUploader(settings)
        self._caption_styles_dir = Path("config/caption_styles")

    @property
    def face_detector(self) -> FaceDetector:
        if self._face_detector is None:
            self._face_detector = FaceDetector()
        return self._face_detector

    @property
    def auto_reframer(self) -> AutoReframer:
        if self._auto_reframer is None:
            self._auto_reframer = AutoReframer(self.face_detector, self.settings.ffmpeg_threads)
        return self._auto_reframer

    @property
    def audio_mixer(self) -> AudioMixer:
        if self._audio_mixer is None:
            self._audio_mixer = AudioMixer(self.storage.base_path / "assets")
        return self._audio_mixer

    async def run(self, project_id: str) -> None:
        """Run the full pipeline for a project.

        This is passed to JobQueue.submit() as the pipeline function.
        """
        project = await self.storage.get_project(project_id)
        if not project:
            logger.error("Project %s not found for pipeline run", project_id)
            return

        try:
            await self._run_stage(project, "download", self._stage_download, ProjectStatus.DOWNLOADING)
            await self._run_stage(project, "extract_audio", self._stage_extract_audio, ProjectStatus.EXTRACTING_AUDIO)
            await self._run_stage(project, "transcribe", self._stage_transcribe, ProjectStatus.TRANSCRIBING)
            await self._run_stage(project, "analyze", self._stage_analyze, ProjectStatus.ANALYZING)
            await self._run_stage(project, "cut", self._stage_cut, ProjectStatus.CUTTING)

            if project.settings.auto_reframe:
                await self._run_stage(project, "reframe", self._stage_reframe, ProjectStatus.REFRAMING)
            else:
                self._mark_stage_skipped(project, "reframe")

            if project.settings.burn_captions:
                await self._run_stage(project, "caption", self._stage_caption, ProjectStatus.CAPTIONING)
            else:
                self._mark_stage_skipped(project, "caption")

            await self._run_stage(project, "export", self._stage_export, ProjectStatus.EXPORTING)
            
            if project.settings.youtube_upload_mode != "off":
                await self._run_stage(project, "upload_youtube", self._stage_upload_youtube, ProjectStatus.EXPORTING)
            else:
                self._mark_stage_skipped(project, "upload_youtube")

            project.status = ProjectStatus.COMPLETED
            project.updated_at = _now()
            await self.storage.update_project(project)
            await self.job_queue.publish_event(project.id, {
                "type": "pipeline_complete",
                "status": ProjectStatus.COMPLETED.value,
                "message": f"All {len(project.clips)} clips exported successfully",
            })

            # Clean up temp files
            await self.storage.cleanup_temp(project.id)
            logger.info("Pipeline completed for project %s — %d clips", project_id[:8], len(project.clips))

        except asyncio.CancelledError:
            project.status = ProjectStatus.CANCELLED
            project.updated_at = _now()
            await self.storage.update_project(project)
            raise
        except Exception as exc:
            logger.exception("Pipeline failed for project %s", project_id[:8])
            project.status = ProjectStatus.FAILED
            project.error = str(exc)
            project.updated_at = _now()
            await self.storage.update_project(project)
            await self.job_queue.publish_event(project.id, {
                "type": "pipeline_failed",
                "status": ProjectStatus.FAILED.value,
                "error": str(exc),
            })

    # ────────────────────────── stage runner ──────────────────────────

    async def _run_stage(
        self,
        project: Project,
        stage_name: str,
        stage_fn: Callable[[Project], Any],
        project_status: ProjectStatus,
    ) -> None:
        """Execute a single pipeline stage with full status tracking."""
        stage = next((s for s in project.stages if s.name == stage_name), None)
        if not stage:
            logger.warning("Stage %s not found in project %s", stage_name, project.id[:8])
            return

        if stage.status == StageStatus.COMPLETED:
            logger.info("Skipping already completed stage %s", stage_name)
            return

        stage.status = StageStatus.RUNNING
        stage.started_at = _now()
        stage.progress = 0.0
        project.status = project_status
        project.updated_at = _now()
        await self.storage.update_project(project)

        await self.job_queue.publish_event(project.id, {
            "type": "stage_start",
            "stage": stage_name,
            "status": StageStatus.RUNNING.value,
            "message": f"Starting {stage_name}...",
        })

        try:
            await stage_fn(project)
            stage.status = StageStatus.COMPLETED
            stage.progress = 1.0
            stage.completed_at = _now()
            project.updated_at = _now()
            await self.storage.update_project(project)
            await self.job_queue.publish_event(project.id, {
                "type": "stage_complete",
                "stage": stage_name,
                "status": StageStatus.COMPLETED.value,
                "message": f"{stage_name} completed",
            })
        except asyncio.CancelledError:
            stage.status = StageStatus.FAILED
            stage.error = "Cancelled"
            project.updated_at = _now()
            await self.storage.update_project(project)
            raise
        except Exception as exc:
            stage.status = StageStatus.FAILED
            stage.error = str(exc)
            stage.retry_count += 1
            project.updated_at = _now()
            await self.storage.update_project(project)
            await self.job_queue.publish_event(project.id, {
                "type": "stage_failed",
                "stage": stage_name,
                "status": StageStatus.FAILED.value,
                "error": str(exc),
            })
            raise

    def _mark_stage_skipped(self, project: Project, stage_name: str) -> None:
        stage = next((s for s in project.stages if s.name == stage_name), None)
        if stage:
            stage.status = StageStatus.SKIPPED

    async def _publish_progress(self, project: Project, stage_name: str, progress: float, message: str = "") -> None:
        stage = next((s for s in project.stages if s.name == stage_name), None)
        if stage:
            stage.progress = min(1.0, progress)
            # Persist every 5% to keep frontend responsive during long stages
            pct = int(progress * 100)
            if pct % 5 == 0 or progress >= 1.0:
                project.updated_at = _now()
                await self.storage.update_project(project)
            await self.job_queue.publish_event(project.id, {
                "type": "stage_progress",
                "stage": stage_name,
                "progress": round(progress, 3),
                "message": message or f"{stage_name.replace('_', ' ').title()} - {pct}%"
            })

    # ────────────────────────── stage implementations ──────────────────────────

    async def _stage_download(self, project: Project) -> None:
        """Stage 1: Download YouTube video."""
        # Reconstruct YouTube URL from video_id stored in cache_dir path
        video_id = Path(project.cache_dir).name if project.cache_dir else ""
        if not video_id:
            raise ValueError("No cache_dir set on project — cannot determine video ID")

        youtube_url = f"https://www.youtube.com/watch?v={video_id}"

        async def on_progress(p: float) -> None:
            await self._publish_progress(project, "download", p)

        # yt-dlp progress hook is sync, so we wrap
        def sync_progress(p: float) -> None:
            try:
                asyncio.get_event_loop().call_soon_threadsafe(
                    lambda: asyncio.create_task(on_progress(p))
                )
            except Exception:
                pass

        result = await self.downloader.download(youtube_url, sync_progress)
        project.video_metadata = result.metadata
        project.cache_dir = str(self.storage.get_cache_dir(video_id))
        logger.info("Downloaded %s — %s (%.0fs)", video_id, result.metadata.title, result.metadata.duration)

    async def _stage_extract_audio(self, project: Project) -> None:
        """Stage 2: Extract audio from video to 16kHz mono WAV."""
        if not project.video_metadata:
            raise PipelineError("No video metadata found on project for audio extraction.")
        video_id = project.video_metadata.video_id
        video_path = self.storage.get_cache_path(video_id, "video.mp4")

        def sync_progress(p: float) -> None:
            try:
                asyncio.get_event_loop().call_soon_threadsafe(
                    lambda: asyncio.create_task(self._publish_progress(project, "extract_audio", p))
                )
            except Exception:
                pass

        await self.audio_extractor.extract(video_path, video_id, sync_progress)
        logger.info("Audio extracted for %s", video_id)

    async def _stage_transcribe(self, project: Project) -> None:
        """Stage 3: Transcribe audio with faster-whisper."""
        if not project.video_metadata:
            raise PipelineError("No video metadata found on project for transcription.")
        video_id = project.video_metadata.video_id
        audio_path = self.storage.get_cache_path(video_id, "audio.wav")

        def sync_progress(p: float, text: str) -> None:
            try:
                asyncio.get_event_loop().call_soon_threadsafe(
                    lambda: asyncio.create_task(self._publish_progress(project, "transcribe", p, message=text))
                )
            except Exception:
                pass

        transcript = await self.transcriber.transcribe(
            audio_path, 
            video_id, 
            self.storage, 
            language=project.settings.language, 
            translate_to_english=project.settings.translate_to_english,
            on_progress=sync_progress
        )
        project.transcript = transcript
        logger.info(
            "Transcribed %s — %d segments, language=%s",
            video_id, len(transcript.segments), transcript.language,
        )

    async def _stage_analyze(self, project: Project) -> None:
        """Stage 4: Analyze transcript for viral moments using LLM."""
        await self._publish_progress(project, "analyze", 0.1)

        if not project.transcript or (not project.transcript.segments and not project.transcript.full_text.strip()):
            raise PipelineError("No speech or spoken words were detected in this video to generate clips from.")

        candidates = await self.viral_analyzer.analyze(
            project.transcript,
            min_score=project.settings.min_clip_score,
            max_clips=project.settings.max_clips,
            min_duration=project.settings.min_clip_duration,
            max_duration=project.settings.max_clip_duration,
        )
        project.viral_candidates = candidates

        project.clips = []
        for i, candidate in enumerate(candidates):
            clip = ProcessedClip(
                clip_id=f"{project.id[:8]}_clip_{i + 1:03d}",
                candidate=candidate,
                duration=candidate.end_time - candidate.start_time,
                caption_style=project.settings.caption_style,
                status=StageStatus.PENDING,
            )
            project.clips.append(clip)

        await self._publish_progress(project, "analyze", 1.0)
        logger.info("Found %d viral candidates for project %s", len(candidates), project.id[:8])

    async def _stage_cut(self, project: Project) -> None:
        """Stage 5: Cut individual clips from source video."""
        if not project.video_metadata:
            raise PipelineError("No video metadata found on project for cutting clips.")
        video_id = project.video_metadata.video_id
        source_video = self.storage.get_cache_path(video_id, "video.mp4")
        output_dir = self.storage.get_output_dir(project.id)

        for i, clip in enumerate(project.clips):
            progress = (i / len(project.clips)) if project.clips else 0
            await self._publish_progress(project, "cut", progress)

            clip_path = output_dir / f"{clip.clip_id}_source.mp4"
            await self.clip_cutter.cut_clip(
                source_video=source_video,
                output_path=clip_path,
                start_time=clip.candidate.start_time,
                end_time=clip.candidate.end_time,
            )
            clip.source_path = str(clip_path)

        await self._publish_progress(project, "cut", 1.0)

    async def _stage_reframe(self, project: Project) -> None:
        """Stage 6: Reframe clips from landscape to 9:16 portrait."""
        output_dir = self.storage.get_output_dir(project.id)
        total_clips = max(len(project.clips), 1)

        for i, clip in enumerate(project.clips):
            # Each clip gets a proportional slice: [base, base + 1/total)
            base = i / total_clips
            clip_weight = 1.0 / total_clips

            await self._publish_progress(
                project, "reframe", base,
                f"Reframing clip {i+1}/{total_clips} — detecting faces..."
            )

            if not clip.source_path:
                continue

            # Sub-progress: face detection = 60% of clip time, encoding = 40%
            await self._publish_progress(
                project, "reframe", base + clip_weight * 0.05,
                f"Clip {i+1}/{total_clips} — extracting frames..."
            )

            reframed_path = output_dir / f"{clip.clip_id}_reframed.mp4"

            # Update progress during face detection phases
            await self._publish_progress(
                project, "reframe", base + clip_weight * 0.15,
                f"Clip {i+1}/{total_clips} — face detection..."
            )

            out_path, cut_timestamps = await self.auto_reframer.reframe(
                input_path=Path(clip.source_path),
                output_path=reframed_path,
                target_width=project.settings.export_width,
                target_height=project.settings.export_height,
                mode=project.settings.reframe_mode,
                zoom_start=getattr(clip.candidate, "zoom_start", None),
                zoom_end=getattr(clip.candidate, "zoom_end", None),
            )
            
            if project.settings.reframe_mode == "podcast":
                # Podcast split-screen and audio mixing (BGM/SFX) disabled by user request
                pass

            clip.reframed_path = str(reframed_path)

            # Clip done
            await self._publish_progress(
                project, "reframe", base + clip_weight,
                f"Clip {i+1}/{total_clips} — reframed ✓"
            )

        await self._publish_progress(project, "reframe", 1.0, "All clips reframed")

    async def _stage_caption(self, project: Project) -> None:
        """Stage 7: Generate ASS captions and burn into clips."""
        output_dir = self.storage.get_output_dir(project.id)
        style = load_caption_style(project.settings.caption_style, self._caption_styles_dir)

        for i, clip in enumerate(project.clips):
            progress = i / max(len(project.clips), 1)
            await self._publish_progress(project, "caption", progress)

            # Find input video (prefer reframed, then source)
            input_video_str = clip.reframed_path or clip.source_path
            if not input_video_str or not Path(input_video_str).exists():
                logger.error("No valid video for captioning clip %s", clip.clip_id)
                clip.status = StageStatus.FAILED
                clip.error = "No video source found for captioning"
                continue
            input_video = Path(input_video_str)

            # Extract word-level timestamps scoped to this clip's time range
            clip_words: list[TranscriptWord] = []
            if project.transcript:
                for segment in project.transcript.segments:
                    for word in segment.words:
                        if word.start >= clip.candidate.start_time and word.end <= clip.candidate.end_time:
                            # Adjust timestamps relative to clip start
                            clip_words.append(TranscriptWord(
                                word=word.word,
                                start=word.start - clip.candidate.start_time,
                                end=word.end - clip.candidate.start_time,
                                confidence=word.confidence,
                            ))

            if not clip_words:
                logger.warning("No words found for clip %s — skipping captions", clip.clip_id)
                continue


            if project.settings.auto_reframe:
                vid_w = project.settings.export_width
                vid_h = project.settings.export_height
            else:
                try:
                    import cv2
                    cap = cv2.VideoCapture(str(input_video))
                    vid_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or project.settings.export_width
                    vid_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or project.settings.export_height
                    cap.release()
                except Exception:
                    vid_w = (project.video_metadata.width if project.video_metadata else None) or 1920
                    vid_h = (project.video_metadata.height if project.video_metadata else None) or 1080

            # Generate ASS subtitle file
            ass_content = self.ass_generator.generate(
                words=clip_words,
                style=style,
                video_width=vid_w,
                video_height=vid_h,
            )
            ass_path = output_dir / f"{clip.clip_id}.ass"
            self.ass_generator.save(ass_content, ass_path)

            # Burn subtitles into video
            captioned_path = output_dir / f"{clip.clip_id}_captioned.mp4"
            await self.caption_burn_in.burn(
                video_path=input_video,
                ass_path=ass_path,
                output_path=captioned_path,
            )
            clip.captioned_path = str(captioned_path)

        await self._publish_progress(project, "caption", 1.0)

    async def _stage_export(self, project: Project) -> None:
        """Stage 8: Final export at target quality + thumbnail generation."""
        output_dir = self.storage.get_output_dir(project.id)

        for i, clip in enumerate(project.clips):
            progress = i / max(len(project.clips), 1)
            await self._publish_progress(project, "export", progress)

            # Pick the best available version
            if clip.captioned_path:
                input_video = Path(clip.captioned_path)
            elif clip.reframed_path:
                input_video = Path(clip.reframed_path)
            elif clip.source_path:
                input_video = Path(clip.source_path)
            else:
                continue

            final_path = output_dir / f"{clip.clip_id}_final.mp4"

            cmd = [
                "ffmpeg", "-y",
                "-i", str(input_video),
                "-c:v", "h264_nvenc",
                "-preset", "p2",
                "-cq", "18",
                "-r", str(project.settings.export_fps),
            ]
            if project.settings.auto_reframe:
                cmd.extend(["-s", f"{project.settings.export_width}x{project.settings.export_height}"])
            else:
                cmd.extend(["-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2"])
            cmd.extend([
                "-c:a", "aac",
                "-b:a", "192k",
                "-af", "aresample=async=1",
                "-vsync", "1",
                str(final_path),
            ])

            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()

            if proc.returncode != 0:
                raise RuntimeError(f"Final export failed for {clip.clip_id}: {stderr.decode()[:500]}")

            clip.final_path = str(final_path)
            clip.status = StageStatus.COMPLETED

            # Generate thumbnail
            thumbnail_path = output_dir / f"{clip.clip_id}_thumb.jpg"
            try:
                await self.thumbnail_generator.generate(final_path, thumbnail_path)
                clip.thumbnail_path = str(thumbnail_path)
            except Exception as exc:
                logger.warning("Thumbnail generation failed for %s: %s", clip.clip_id, exc)

        await self._publish_progress(project, "export", 1.0)
        
    async def _stage_upload_youtube(self, project: Project) -> None:
        """Stage 9: Upload to YouTube if enabled."""
        if project.settings.youtube_upload_mode == "off":
            return
            
        for i, clip in enumerate(project.clips):
            progress = i / max(len(project.clips), 1)
            await self._publish_progress(project, "upload_youtube", progress, message=f"Uploading clip {i+1} of {len(project.clips)}")
            
            try:
                await self.youtube_uploader.upload_clip(project, clip, i)
            except Exception as e:
                logger.error(f"Failed to upload clip {clip.clip_id} to YouTube: {e}")
                # We don't raise here so one failed upload doesn't fail the whole pipeline
                clip.error = f"YouTube upload failed: {e}"
                
        await self._publish_progress(project, "upload_youtube", 1.0, message="Uploads complete")

