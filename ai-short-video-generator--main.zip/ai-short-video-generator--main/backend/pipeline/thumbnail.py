import asyncio
from pathlib import Path

class ThumbnailGenerator:
    """Generates thumbnails from video files."""
    
    async def generate(self, video_path: Path, output_path: Path, time_offset: float = 0.5) -> Path:
        """Extract a frame from video as thumbnail.
        
        FFmpeg: ffmpeg -ss time -i input -vframes 1 -q:v 2 output.jpg
        """
        cmd = [
            "ffmpeg", "-y",
            "-ss", str(time_offset),
            "-i", str(video_path),
            "-vframes", "1",
            "-q:v", "2",
            str(output_path)
        ]
        
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await proc.communicate()
        
        if proc.returncode != 0:
            raise Exception(f"Failed to generate thumbnail: {stderr.decode()}")
            
        return output_path
