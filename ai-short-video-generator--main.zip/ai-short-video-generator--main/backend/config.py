"""Application configuration with auto GPU/model detection."""

from __future__ import annotations

import logging
import os
import shutil
from functools import lru_cache
from pathlib import Path

import psutil
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)


def _detect_device() -> str:
    """Detect the best available compute device: MPS → CUDA → CPU."""
    try:
        import torch
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return "mps"
        if torch.cuda.is_available():
            return "cuda"
    except ImportError:
        pass
    return "cpu"


def _detect_compute_type(device: str) -> str:
    """Select compute type based on device."""
    if device == "cuda":
        return "float16"
    if device == "mps":
        return "float32"
    return "int8"


def _detect_whisper_model() -> str:
    """Select the largest Whisper model that fits in available RAM."""
    available_gb = psutil.virtual_memory().available / (1024**3)
    thresholds = [
        (10.0, "large-v3"),
        (5.0, "medium"),
        (2.0, "small"),
        (1.0, "base"),
    ]
    for min_gb, model in thresholds:
        if available_gb >= min_gb:
            return model
    return "tiny"


def _get_ffmpeg_version() -> str:
    """Get FFmpeg version string or raise if not installed."""
    import subprocess

    ffmpeg_path = shutil.which("ffmpeg")
    if not ffmpeg_path:
        raise RuntimeError(
            "FFmpeg not found. Install with: brew install ffmpeg"
        )
    try:
        result = subprocess.run(
            ["ffmpeg", "-version"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        first_line = result.stdout.split("\n")[0]
        return first_line.split("version ")[-1].split(" ")[0] if "version" in first_line else "unknown"
    except Exception:
        return "unknown"


class Settings(BaseSettings):
    """Application settings loaded from .env file and environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # API Keys
    gemini_api_key: str = ""
    google_api_key: str = ""
    llm_provider: str = "gemini"
    llm_model: str = "auto"
    
    # YouTube OAuth
    youtube_client_id: str = ""
    youtube_client_secret: str = ""

    # Whisper
    whisper_model_size: str = "auto"
    whisper_device: str = "auto"
    whisper_compute_type: str = "auto"

    # Video processing
    ffmpeg_threads: int = 0
    max_parallel_clips: int = 4

    # Clip selection
    min_clip_score: int = 75
    max_clips: int = 10
    clip_min_duration: int = 15
    clip_max_duration: int = 60

    # Storage
    storage_path: str = "./storage"

    # Server
    backend_port: int = 8000
    frontend_port: int = 3001
    log_level: str = "INFO"

    # Resolved at runtime (not from env)
    _resolved_device: str = ""
    _resolved_whisper_model: str = ""
    _resolved_compute_type: str = ""
    _ffmpeg_version: str = ""

    @property
    def storage_dir(self) -> Path:
        return Path(self.storage_path).resolve()

    @property
    def resolved_device(self) -> str:
        return self._resolved_device

    @property
    def resolved_whisper_model(self) -> str:
        return self._resolved_whisper_model

    @property
    def resolved_compute_type(self) -> str:
        return self._resolved_compute_type

    @property
    def ffmpeg_version(self) -> str:
        return self._ffmpeg_version

    def resolve_runtime_settings(self) -> None:
        """Resolve auto-detected settings. Call once at startup."""
        if self.gemini_api_key:
            os.environ["GEMINI_API_KEY"] = self.gemini_api_key
        if self.google_api_key:
            os.environ["GOOGLE_API_KEY"] = self.google_api_key
        # GPU / device

        if self.whisper_device == "auto":
            self._resolved_device = _detect_device()
        else:
            self._resolved_device = self.whisper_device

        # Whisper model
        if self.whisper_model_size == "auto":
            self._resolved_whisper_model = _detect_whisper_model()
        else:
            self._resolved_whisper_model = self.whisper_model_size

        # Compute type
        if self.whisper_compute_type == "auto":
            self._resolved_compute_type = _detect_compute_type(self._resolved_device)
        else:
            self._resolved_compute_type = self.whisper_compute_type

        # FFmpeg
        self._ffmpeg_version = _get_ffmpeg_version()

        # Storage directories
        _init_storage(self.storage_dir)

        ram = psutil.virtual_memory()
        logger.info(
            "Runtime config resolved: device=%s, whisper_model=%s, "
            "compute_type=%s, ffmpeg=%s, ram_available=%.1fGB",
            self._resolved_device,
            self._resolved_whisper_model,
            self._resolved_compute_type,
            self._ffmpeg_version,
            ram.available / (1024**3),
        )


def _init_storage(base: Path) -> None:
    """Create all required storage subdirectories."""
    for name in [
        "uploads", "projects", "outputs", "temp",
        "cache", "thumbnails", "transcripts", "logs",
    ]:
        (base / name).mkdir(parents=True, exist_ok=True)


@lru_cache
def get_settings() -> Settings:
    """Return the singleton Settings instance with resolved runtime values."""
    settings = Settings()
    settings.resolve_runtime_settings()
    return settings
