"""SSE status streaming routes."""

from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse

from backend.dependencies import get_job_queue
from backend.services.job_queue import JobQueue

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/status", tags=["status"])


@router.get("/{project_id}/events")
async def project_events(
    project_id: str,
    request: Request,
    job_queue: JobQueue = Depends(get_job_queue),
) -> StreamingResponse:
    """Stream SSE events for a project's processing pipeline."""

    async def event_generator():
        try:
            async for event in job_queue.subscribe(project_id):
                if await request.is_disconnected():
                    break
                data = json.dumps(event, default=str)
                yield f"data: {data}\n\n"
        except Exception:
            logger.debug("SSE stream ended for project %s", project_id[:8])

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
