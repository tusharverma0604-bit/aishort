"""Clip management API routes."""

from __future__ import annotations

import io
import logging
import zipfile
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse, StreamingResponse

from backend.dependencies import get_storage
from backend.models.api import ClipListResponse
from backend.services.storage import StorageService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/projects/{project_id}/clips", tags=["clips"])


@router.get("")
@router.get("/", response_model=ClipListResponse)
async def list_clips(
    project_id: str,
    storage: StorageService = Depends(get_storage),
) -> ClipListResponse:
    """List all clips for a project."""
    project = await storage.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return ClipListResponse(clips=project.clips, total=len(project.clips))


@router.get("/{clip_id}/download")
async def download_clip(
    project_id: str,
    clip_id: str,
    storage: StorageService = Depends(get_storage),
) -> FileResponse:
    """Download a single clip as an MP4 file."""
    project = await storage.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    clip = next((c for c in project.clips if c.clip_id == clip_id), None)
    if not clip:
        raise HTTPException(status_code=404, detail="Clip not found")

    clip_path = clip.final_path or clip.captioned_path or clip.reframed_path or clip.source_path
    if not clip_path or not Path(clip_path).exists():
        raise HTTPException(status_code=404, detail="Clip file not found on disk")

    return FileResponse(
        clip_path,
        media_type="video/mp4",
        filename=f"{clip.candidate.title or clip_id}.mp4",
    )


@router.get("/download-all")
async def download_all_clips(
    project_id: str,
    storage: StorageService = Depends(get_storage),
) -> StreamingResponse:
    """Download all clips as a ZIP archive."""
    project = await storage.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    available_clips = [
        c for c in project.clips
        if (c.final_path and Path(c.final_path).exists())
    ]
    if not available_clips:
        raise HTTPException(status_code=404, detail="No clips available for download")

    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for clip in available_clips:
            clip_path = Path(clip.final_path)  # type: ignore[arg-type]
            safe_name = clip.candidate.title.replace("/", "-").replace("\\", "-")
            zf.write(clip_path, arcname=f"{safe_name}.mp4")

    zip_buffer.seek(0)
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="project_{project_id[:8]}_clips.zip"'
        },
    )


@router.get("/{clip_id}/thumbnail")
async def get_thumbnail(
    project_id: str,
    clip_id: str,
    storage: StorageService = Depends(get_storage),
) -> FileResponse:
    """Get the thumbnail image for a clip."""
    project = await storage.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    clip = next((c for c in project.clips if c.clip_id == clip_id), None)
    if not clip or not clip.thumbnail_path or not Path(clip.thumbnail_path).exists():
        raise HTTPException(status_code=404, detail="Thumbnail not found")

    return FileResponse(clip.thumbnail_path, media_type="image/jpeg")
