"""System information and health check routes."""

from __future__ import annotations

import logging
from datetime import datetime, timezone

import psutil
from fastapi import APIRouter, Depends

from backend.config import Settings
from backend.config_manager import AppConfig, ConfigManager
from backend.dependencies import get_app_config_manager, get_config
from backend.models.api import SystemInfoResponse

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/system", tags=["system"])


@router.get("/config", response_model=AppConfig)
async def get_app_config(
    config_manager: ConfigManager = Depends(get_app_config_manager)
) -> AppConfig:
    """Get the current application configuration (API keys, defaults)."""
    return config_manager.get_config()


@router.post("/config", response_model=AppConfig)
async def update_app_config(
    new_config: AppConfig,
    config_manager: ConfigManager = Depends(get_app_config_manager)
) -> AppConfig:
    """Update the application configuration."""
    config_manager.save_config(new_config)
    return config_manager.get_config()


@router.get("/info", response_model=SystemInfoResponse)
async def system_info(
    config: Settings = Depends(get_config),
) -> SystemInfoResponse:
    """Return system information including GPU, RAM, and model config."""
    ram = psutil.virtual_memory()
    return SystemInfoResponse(
        gpu_device=config.resolved_device,
        gpu_available=config.resolved_device != "cpu",
        ram_total_gb=round(ram.total / (1024**3), 1),
        ram_available_gb=round(ram.available / (1024**3), 1),
        whisper_model=config.resolved_whisper_model,
        whisper_device=config.resolved_device,
        ffmpeg_version=config.ffmpeg_version,
        storage_path=str(config.storage_dir),
        llm_provider=config.llm_provider,
        llm_model=config.llm_model,
    )


@router.get("/health")
async def health_check() -> dict[str, str]:
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
