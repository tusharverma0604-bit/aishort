"""Project management API routes."""

from __future__ import annotations

import logging
import re
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, File, UploadFile
from pydantic import BaseModel

from backend.config import get_settings
from backend.dependencies import get_job_queue, get_storage
from backend.models.api import (
    CreateProjectRequest,
    CreateProjectResponse,
    ProjectStatusResponse,
)
from backend.models.project import (
    Project,
    ProjectSettings,
    ProjectStatus,
    StageInfo,
    StageStatus,
)
from backend.services.job_queue import JobQueue
from backend.services.storage import StorageService
from backend.pipeline.orchestrator import PipelineOrchestrator
from backend.services.youtube_uploader import YouTubeUploader

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/projects", tags=["projects"])

YOUTUBE_PATTERNS = [
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/watch\?.*v=([a-zA-Z0-9_-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtu\.be/([a-zA-Z0-9_-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/shorts/([a-zA-Z0-9_-]{11})"),
]

PIPELINE_STAGES = [
    "download", "extract_audio", "transcribe",
    "analyze", "cut", "reframe", "caption", "export", "upload_youtube"
]


def extract_video_id(url: str) -> str:
    """Extract YouTube video ID from URL."""
    url = url.strip()
    if len(url) == 11 and re.match(r"^[a-zA-Z0-9_-]{11}$", url):
        return url
        
    for pattern in YOUTUBE_PATTERNS:
        match = pattern.search(url)
        if match:
            return match.group(1)
            
    # Fallback to broader pattern used by downloader.py
    match = re.search(r"(?:v=|\/)([0-9A-Za-z_-]{11}).*", url)
    if match:
        return match.group(1)
        
    raise ValueError(f"Could not extract video ID from: {url}")




@router.post("")
@router.post("/", response_model=CreateProjectResponse, status_code=201)
async def create_project(
    request: CreateProjectRequest,
    api_request: Request,
    storage: StorageService = Depends(get_storage),
    job_queue: JobQueue = Depends(get_job_queue),
) -> CreateProjectResponse:
    """Create a new project from a YouTube URL and start processing."""
    try:
        video_id = extract_video_id(request.youtube_url)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    project_id = str(uuid.uuid4())
    settings = request.settings or ProjectSettings()

    project = Project(
        id=project_id,
        settings=settings,
        cache_dir=str(storage.get_cache_dir(video_id)),
    )
    project.stages = [StageInfo(name=name) for name in PIPELINE_STAGES]

    await storage.create_project(project)
    
    orchestrator = PipelineOrchestrator(
        storage, 
        job_queue, 
        api_request.app.state.config,
        api_request.app.state.app_config_manager.get_config()
    )
    await job_queue.submit(project_id, orchestrator.run)

    logger.info("Created project %s for video %s", project_id[:8], video_id)
    return CreateProjectResponse(project_id=project_id, status=ProjectStatus.PENDING)


@router.get("")
@router.get("/", response_model=list[ProjectStatusResponse])
async def list_projects(
    storage: StorageService = Depends(get_storage),
) -> list[ProjectStatusResponse]:
    """List all projects."""
    projects = await storage.list_projects()
    return [ProjectStatusResponse(project=p) for p in projects]


@router.get("/{project_id}", response_model=ProjectStatusResponse)
async def get_project(
    project_id: str,
    storage: StorageService = Depends(get_storage),
) -> ProjectStatusResponse:
    """Get a project by ID."""
    project = await storage.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return ProjectStatusResponse(project=project)


@router.delete("/{project_id}")
async def delete_project(
    project_id: str,
    storage: StorageService = Depends(get_storage),
    job_queue: JobQueue = Depends(get_job_queue),
) -> dict[str, str]:
    """Delete a project and cancel any active jobs."""
    project = await storage.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    await job_queue.cancel_by_project(project_id)
    await storage.delete_project(project_id)
    return {"message": f"Project {project_id} deleted"}


@router.post("/{project_id}/cancel")
async def cancel_project(
    project_id: str,
    storage: StorageService = Depends(get_storage),
    job_queue: JobQueue = Depends(get_job_queue),
) -> dict[str, str]:
    """Cancel processing for a project."""
    project = await storage.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    cancelled = await job_queue.cancel_by_project(project_id)
    
    # Always mark as cancelled in storage, even if it wasn't running in the queue 
    # (e.g., if it was orphaned after a server restart)
    if project.status not in (ProjectStatus.COMPLETED, ProjectStatus.FAILED, ProjectStatus.CANCELLED):
        project.status = ProjectStatus.CANCELLED
        await storage.update_project(project)
        return {"message": "Processing cancelled"}
        
    if cancelled:
        return {"message": "Processing cancelled"}
        
    return {"message": "No active job to cancel"}


@router.post("/{project_id}/retry")
async def retry_project(
    project_id: str,
    api_request: Request,
    storage: StorageService = Depends(get_storage),
    job_queue: JobQueue = Depends(get_job_queue),
) -> dict[str, str]:
    """Retry processing for a failed project."""
    project = await storage.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    project.status = ProjectStatus.PENDING
    project.error = None
    
    # Reset all failed/running stages to PENDING so they get re-executed
    # Completed stages are left alone — _run_stage skips them automatically
    if project.stages:
        for stage in project.stages:
            if stage.status in (StageStatus.FAILED, StageStatus.RUNNING):
                stage.status = StageStatus.PENDING
                stage.progress = 0.0
                stage.error = None
                stage.started_at = None
                stage.completed_at = None
    
    await storage.update_project(project)

    orchestrator = PipelineOrchestrator(
        storage, 
        job_queue, 
        api_request.app.state.config,
        api_request.app.state.app_config_manager.get_config()
    )
    await job_queue.submit(project_id, orchestrator.run)
    return {"message": "Processing restarted"}

class YouTubeUploadRequest(BaseModel):
    privacy_status: str = "private" # "public" or "private"

@router.post("/{project_id}/clips/{clip_id}/youtube_upload")
async def manual_youtube_upload(
    project_id: str,
    clip_id: str,
    request_data: YouTubeUploadRequest,
    storage: StorageService = Depends(get_storage),
) -> dict[str, str]:
    """Manually upload a generated clip to YouTube."""
    project = await storage.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    clip = next((c for c in project.clips if c.clip_id == clip_id), None)
    if not clip:
        raise HTTPException(status_code=404, detail="Clip not found")

    # Briefly change settings for this single upload to match user intent
    settings = get_settings()
    uploader = YouTubeUploader(settings)
    
    # Temporarily override the mode so the uploader processes it
    original_mode = project.settings.youtube_upload_mode
    project.settings.youtube_upload_mode = request_data.privacy_status
    
    try:
        video_id = await uploader.upload_clip(project, clip, clip_index=0)
        if not video_id:
            raise HTTPException(status_code=400, detail="Failed to upload video (maybe not connected to YouTube)")
            
        clip.youtube_url = f"https://youtube.com/shorts/{video_id}"
        await storage.update_project(project)
        return {"youtube_url": clip.youtube_url, "video_id": video_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        # Restore mode
        project.settings.youtube_upload_mode = original_mode
        await storage.update_project(project)
