import requests
import json
import logging
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, HTTPException, Request, Depends
from fastapi.responses import RedirectResponse
from google.oauth2.credentials import Credentials

from backend.config import get_settings, Settings
from backend.dependencies import get_app_config_manager

logger = logging.getLogger(__name__)
router = APIRouter()

# Scopes needed for YouTube upload
SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

def get_credentials_path(settings: Settings) -> Path:
    return settings.storage_dir / "youtube_credentials.json"

def _get_youtube_creds(settings: Settings, app_config_manager) -> tuple[str, str]:
    """Helper to get dynamic youtube client id/secret falling back to settings."""
    app_config = app_config_manager.get_config()
    client_id = app_config.youtube_client_id or settings.youtube_client_id
    client_secret = app_config.youtube_client_secret or settings.youtube_client_secret
    return client_id, client_secret

@router.post("/auth/device")
async def youtube_auth_device(
    settings: Settings = Depends(get_settings),
    app_config_manager = Depends(get_app_config_manager)
):
    """Start the Device Authorization Flow."""
    client_id, _ = _get_youtube_creds(settings, app_config_manager)
    
    if not client_id:
        raise HTTPException(status_code=500, detail="YouTube Client ID not configured.")
        
    logger.info("[DEBUG] Starting YouTube Device Authorization Flow")
    
    # Request device code
    data = {
        "client_id": client_id,
        "scope": " ".join(SCOPES)
    }
    
    response = requests.post("https://oauth2.googleapis.com/device/code", data=data)
    
    if response.status_code != 200:
        logger.error(f"Device flow error: {response.text}")
        raise HTTPException(status_code=500, detail="Failed to initiate device flow.")
        
    res_data = response.json()
    
    return {
        "device_code": res_data["device_code"],
        "user_code": res_data["user_code"],
        "verification_url": res_data["verification_url"],
        "expires_in": res_data["expires_in"],
        "interval": res_data["interval"]
    }

@router.post("/auth/device/poll")
async def youtube_auth_device_poll(
    request: Request, 
    settings: Settings = Depends(get_settings),
    app_config_manager = Depends(get_app_config_manager)
):
    """Poll for the device authorization completion."""
    body = await request.json()
    device_code = body.get("device_code")
    
    if not device_code:
        raise HTTPException(status_code=400, detail="device_code required")
        
    client_id, client_secret = _get_youtube_creds(settings, app_config_manager)
    
    data = {
        "client_id": client_id,
        "client_secret": client_secret,
        "device_code": device_code,
        "grant_type": "urn:ietf:params:oauth:grant-type:device_code"
    }
    
    response = requests.post("https://oauth2.googleapis.com/token", data=data)
    res_data = response.json()
    
    if response.status_code == 200:
        # Success! User authorized.
        creds_data = {
            'token': res_data.get('access_token'),
            'refresh_token': res_data.get('refresh_token'),
            'token_uri': "https://oauth2.googleapis.com/token",
            'client_id': settings.youtube_client_id,
            'client_secret': settings.youtube_client_secret,
            'scopes': SCOPES
        }
        
        creds_path = get_credentials_path(settings)
        with open(creds_path, 'w') as f:
            json.dump(creds_data, f)
            
        logger.info("YouTube credentials saved successfully via Device Flow.")
        return {"status": "connected"}
        
    elif response.status_code == 400 or response.status_code == 428: # 428 Precondition Required is sometimes used, but Google uses 400
        error = res_data.get("error")
        if error == "authorization_pending":
            return {"status": "pending"}
        elif error == "slow_down":
            return {"status": "pending"}
        elif error == "expired_token":
            raise HTTPException(status_code=400, detail="Code expired. Please try again.")
        elif error == "access_denied":
            raise HTTPException(status_code=403, detail="Access denied by user.")
        else:
            logger.error(f"Polling error: {res_data}")
            raise HTTPException(status_code=400, detail=f"OAuth Error: {error}")
    else:
        logger.error(f"Unknown polling error: {response.text}")
        raise HTTPException(status_code=500, detail="Internal server error during polling.")

@router.get("/status")
async def youtube_status(settings: Settings = Depends(get_settings)):
    """Check if YouTube is connected."""
    creds_path = get_credentials_path(settings)
    is_connected = creds_path.exists()
    return {"connected": is_connected}

@router.post("/disconnect")
async def youtube_disconnect(settings: Settings = Depends(get_settings)):
    """Disconnect YouTube by deleting the credentials file."""
    creds_path = get_credentials_path(settings)
    if creds_path.exists():
        creds_path.unlink()
        logger.info("YouTube credentials deleted.")
    return {"status": "disconnected"}
