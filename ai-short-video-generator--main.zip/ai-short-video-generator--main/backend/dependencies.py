from fastapi import Request
from backend.services.storage import StorageService
from backend.services.job_queue import JobQueue
from backend.config import Settings

def get_storage(request: Request) -> StorageService:
    return request.app.state.storage

def get_job_queue(request: Request) -> JobQueue:
    return request.app.state.job_queue

def get_config(request: Request) -> Settings:
    return request.app.state.config

def get_app_config_manager(request: Request):
    return request.app.state.app_config_manager
