from pathlib import Path

from backend.models.project import Transcript


def _format_timestamp(seconds: float) -> str:
    """Format seconds into SRT timestamp format: HH:MM:SS,mmm"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millisecs = int((seconds - int(seconds)) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millisecs:03d}"


def transcript_to_srt(transcript: Transcript) -> str:
    """Convert Transcript to SRT subtitle format."""
    lines = []
    for i, segment in enumerate(transcript.segments, start=1):
        start_time = _format_timestamp(segment.start)
        end_time = _format_timestamp(segment.end)
        text = segment.text.strip()
        
        lines.append(str(i))
        lines.append(f"{start_time} --> {end_time}")
        lines.append(text)
        lines.append("")  # Empty line between subtitles
        
    return "\n".join(lines)


def save_srt(transcript: Transcript, output_path: Path) -> None:
    """Save transcript as SRT file."""
    srt_content = transcript_to_srt(transcript)
    output_path.write_text(srt_content, encoding="utf-8")
