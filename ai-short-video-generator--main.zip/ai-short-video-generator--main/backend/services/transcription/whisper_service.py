import asyncio
import json
import logging
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, Optional, TYPE_CHECKING

import aiofiles

from backend.models.project import Transcript, TranscriptSegment, TranscriptWord
from backend.services.storage import StorageService

if TYPE_CHECKING:
    from faster_whisper import WhisperModel

logger = logging.getLogger(__name__)

class WhisperTranscriptionService:
    """Transcription service using faster-whisper."""
    
    # Class-level singletons to prevent memory/thread leaks
    _model_instance: Optional["WhisperModel"] = None
    _executor: Optional[ThreadPoolExecutor] = None
    
    def __init__(self, model_size: str, device: str, compute_type: str):
        self._model_size = model_size
        self._device = device
        self._compute_type = compute_type
        
        if WhisperTranscriptionService._executor is None:
            WhisperTranscriptionService._executor = ThreadPoolExecutor(max_workers=1)
    
    def _get_model(self) -> "WhisperModel":
        """Lazy-load Whisper model."""
        if WhisperTranscriptionService._model_instance is None:
            from faster_whisper import WhisperModel
            # IMPORTANT: faster-whisper uses CTranslate2 which does NOT support MPS
            # On Apple Silicon, use device='cpu' with compute_type='int8' for best perf
            actual_device = 'cpu' if self._device == 'mps' else self._device
            actual_compute = 'int8' if actual_device == 'cpu' and self._compute_type == 'float16' else self._compute_type
            
            logger.info(f"Loading Whisper model: {self._model_size} on {actual_device} with {actual_compute} (8 threads)")
            WhisperTranscriptionService._model_instance = WhisperModel(
                self._model_size,
                device=actual_device,
                compute_type=actual_compute,
                cpu_threads=8,
            )
        return WhisperTranscriptionService._model_instance
    
    def _run_transcription(
        self,
        audio_path: Path,
        language: Optional[str] = None,
        translate_to_english: bool = False,
        on_progress: Optional[Callable] = None,
    ) -> Transcript:
        model = self._get_model()
        
        task_mode = "translate" if translate_to_english else "transcribe"
        logger.info(f"Running Whisper task '{task_mode}' on {audio_path} (language={language or 'auto-detect'}, beam_size=5)")

        # NOTE: We do NOT pass an English initial_prompt when language is None or non-English.
        # As community research shows, passing an English initial_prompt to Whisper when transcribing
        # Telugu or Indian languages biases the attention weights toward Urdu/English script and causes dots (...).
        # We rely on clean VAD segmentation, beam_size=5, and compression_ratio_threshold to stop hallucinations.
        segments_generator, info = model.transcribe(
            str(audio_path),
            language=language,
            task=task_mode,
            beam_size=5,
            best_of=5,
            temperature=(0.0, 0.2, 0.4, 0.6, 0.8, 1.0),
            condition_on_previous_text=False,  # CRITICAL: Prevents infinite hallucination loops
            compression_ratio_threshold=2.4,
            log_prob_threshold=-1.0,
            no_speech_threshold=0.65,
            word_timestamps=True,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500, speech_pad_ms=400, threshold=0.35),
        )
        
        return self._segments_to_transcript(segments_generator, info, on_progress)
    
    async def transcribe(
        self,
        audio_path: Path,
        video_id: str,
        storage: StorageService,
        language: Optional[str] = None,
        translate_to_english: bool = False,
        on_progress: Optional[Callable] = None,
    ) -> Transcript:
        """Transcribe audio file and return Transcript model.
        
        - Check cache: if cache/{video_id}/transcript.json exists, load and return
        - Transcribe using faster-whisper with word_timestamps=True
        - Convert segments to TranscriptSegment/TranscriptWord models
        - Cache result as JSON
        - Return Transcript
        """
        cache_filename = "transcript.json"
        
        if storage.is_cached(video_id, cache_filename):
            cache_path = storage.get_cache_path(video_id, cache_filename)
            logger.info(f"Loading cached transcript for {video_id} from {cache_path}")
            try:
                async with aiofiles.open(cache_path, 'r', encoding='utf-8') as f:
                    content = await f.read()
                    data = json.loads(content)
                    return Transcript.model_validate(data)
            except Exception as e:
                logger.warning(f"Failed to load cached transcript, re-transcribing: {e}")
        
        # Run blocking transcription in thread pool
        loop = asyncio.get_running_loop()
        transcript = await loop.run_in_executor(
            WhisperTranscriptionService._executor,
            self._run_transcription,
            audio_path,
            language,
            translate_to_english,
            on_progress
        )
        
        # Cache the result
        cache_path = storage.get_cache_path(video_id, cache_filename)
        try:
            async with aiofiles.open(cache_path, 'w', encoding='utf-8') as f:
                content = transcript.model_dump_json(indent=2)
                await f.write(content)
        except Exception as e:
            logger.error(f"Failed to cache transcript: {e}")
            
        return transcript
        
    def _segments_to_transcript(self, segments, info, on_progress: Optional[Callable] = None) -> Transcript:
        """Convert faster-whisper segments to Transcript model."""
        transcript_segments = []
        full_text_parts = []
        
        count = 0
        
        for segment in segments:
            words = []
            if segment.words:
                for word in segment.words:
                    words.append(
                        TranscriptWord(
                            word=word.word,
                            start=word.start,
                            end=word.end,
                            confidence=word.probability,
                        )
                    )
            
            transcript_segment = TranscriptSegment(
                start=segment.start,
                end=segment.end,
                text=segment.text,
                words=words,
            )
            transcript_segments.append(transcript_segment)
            full_text_parts.append(segment.text)
            
            count += 1
            if on_progress:
                try:
                    progress = min(1.0, segment.end / info.duration) if info.duration else 0.0
                    on_progress(progress, segment.text)
                except Exception as e:
                    logger.warning(f"Error in progress callback: {e}")
            
            if count % 10 == 0:
                logger.info(f"Transcribed {count} segments...")
        
        logger.info(f"Transcription complete: {count} segments, language: {info.language}, duration: {info.duration}s")
        
        return Transcript(
            language=info.language,
            segments=transcript_segments,
            full_text="".join(full_text_parts),
        )
