import asyncio
import json
import shutil
from pathlib import Path
from typing import List, Optional

import aiofiles
try:
    import orjson
except ImportError:
    orjson = None

from backend.models.project import Project

class StorageService:
    """File-based storage for projects and cache."""
    
    def __init__(self, base_path: Path):
        self.base_path = Path(base_path)
        self.projects_dir = self.base_path / "projects"
        self.cache_dir = self.base_path / "cache"
        self.outputs_dir = self.base_path / "outputs"
        self.temp_dir = self.base_path / "temp"
        
        # Create directories
        for directory in [self.projects_dir, self.cache_dir, self.outputs_dir, self.temp_dir]:
            directory.mkdir(parents=True, exist_ok=True)
            
        self._lock = asyncio.Lock()

    async def _read_json(self, path: Path) -> dict:
        if not path.exists():
            return {}
        async with aiofiles.open(path, 'r', encoding='utf-8') as f:
            content = await f.read()
            if not content.strip():
                return {}
            
            # Run JSON parsing in a thread to avoid blocking the async event loop on huge files
            def parse_json(c: str) -> dict:
                if orjson:
                    return orjson.loads(c)
                return json.loads(c)
                
            return await asyncio.to_thread(parse_json, content)

    async def _write_json_atomic(self, path: Path, data: dict) -> None:
        async with self._lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            temp_path = path.with_suffix('.tmp')
            
            if orjson:
                content = orjson.dumps(data).decode('utf-8')
            else:
                content = json.dumps(data)
                
            async with aiofiles.open(temp_path, 'w', encoding='utf-8') as f:
                await f.write(content)
                
            # Replace is atomic on POSIX
            temp_path.replace(path)

    async def create_project(self, project: Project) -> None:
        project_dir = self.projects_dir / project.id
        project_dir.mkdir(parents=True, exist_ok=True)
        project_file = project_dir / "project.json"
        
        data = project.model_dump(mode='json')
        await self._write_json_atomic(project_file, data)
        await self._write_summary(project_dir, data)

    async def get_project(self, project_id: str) -> Optional[Project]:
        project_file = self.projects_dir / project_id / "project.json"
        if not project_file.exists():
            return None
        data = await self._read_json(project_file)
        return Project(**data) if data else None

    async def _write_summary(self, project_dir: Path, data: dict) -> None:
        summary_data = data.copy()
        summary_data.pop('transcript', None)
        summary_data.pop('viral_candidates', None)
        summary_file = project_dir / "summary.json"
        await self._write_json_atomic(summary_file, summary_data)

    async def update_project(self, project: Project) -> None:
        project_file = self.projects_dir / project.id / "project.json"
        data = project.model_dump(mode='json')
        await self._write_json_atomic(project_file, data)
        await self._write_summary(self.projects_dir / project.id, data)

    async def delete_project(self, project_id: str) -> None:
        async with self._lock:
            project_dir = self.projects_dir / project_id
            if project_dir.exists():
                shutil.rmtree(project_dir)
                
            output_dir = self.outputs_dir / project_id
            if output_dir.exists():
                shutil.rmtree(output_dir)
                
            temp_dir = self.temp_dir / project_id
            if temp_dir.exists():
                shutil.rmtree(temp_dir)

    async def list_projects(self) -> List[Project]:
        if not self.projects_dir.exists():
            return []
            
        async def _read_project_summary(project_dir: Path) -> Optional[Project]:
            if not project_dir.is_dir():
                return None
            
            # Fast path: read summary.json if it exists (very small file)
            summary_file = project_dir / "summary.json"
            if summary_file.exists():
                try:
                    data = await self._read_json(summary_file)
                    if data:
                        return Project(**data)
                except Exception:
                    pass

            # Slow path: read huge project.json and generate summary
            project_file = project_dir / "project.json"
            if not project_file.exists():
                return None
            try:
                data = await self._read_json(project_file)
                if data:
                    await self._write_summary(project_dir, data)
                    data.pop('transcript', None)
                    data.pop('viral_candidates', None)
                    return Project(**data)
            except Exception:
                pass
            return None

        tasks = [_read_project_summary(d) for d in self.projects_dir.iterdir()]
        results = await asyncio.gather(*tasks)
        return [r for r in results if r is not None]

    def get_cache_dir(self, video_id: str) -> Path:
        cache_dir = self.cache_dir / video_id
        cache_dir.mkdir(parents=True, exist_ok=True)
        return cache_dir

    def is_cached(self, video_id: str, filename: str) -> bool:
        cache_file = self.get_cache_dir(video_id) / filename
        return cache_file.exists()

    def get_cache_path(self, video_id: str, filename: str) -> Path:
        return self.get_cache_dir(video_id) / filename

    def get_output_dir(self, project_id: str) -> Path:
        output_dir = self.outputs_dir / project_id
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir

    def get_temp_dir(self, project_id: str) -> Path:
        temp_dir = self.temp_dir / project_id
        temp_dir.mkdir(parents=True, exist_ok=True)
        return temp_dir

    async def cleanup_temp(self, project_id: str) -> None:
        async with self._lock:
            temp_dir = self.temp_dir / project_id
            if temp_dir.exists():
                shutil.rmtree(temp_dir)
