from pathlib import Path
from backend.models.project import TranscriptWord
from backend.services.captions.style_loader import CaptionStyle


class ASSGenerator:
    """Generates ASS (Advanced SubStation Alpha) subtitle files.
    
    ASS format supports:
    - Rich text formatting
    - Custom fonts, colors, borders
    - Karaoke timing (per-word highlighting)
    - Position control
    - Animation effects
    """

    def _hex_to_ass_color(self, hex_color: str, default_alpha: str = "00") -> str:
        """Convert #RRGGBB or rgba/transparent to ASS color format &HBBGGRR&"""
        if hex_color.lower() == "transparent":
            return "&HFF000000&"
        if hex_color.startswith("rgba"):
            # Simple fallback for rgba
            return "&H80000000&"
        
        hex_val = hex_color.lstrip('#')
        if len(hex_val) == 6:
            r, g, b = hex_val[0:2], hex_val[2:4], hex_val[4:6]
            return f"&H{default_alpha}{b}{g}{r}&"
        
        return f"&H{default_alpha}FFFFFF&"

    def _format_time(self, seconds: float) -> str:
        """Format seconds to ASS time format: H:MM:SS.cs"""
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = seconds % 60
        return f"{h}:{m:02d}:{s:05.2f}"

    def _group_words_into_lines(self, words: list[TranscriptWord], max_per_line: int) -> list[list[TranscriptWord]]:
        """Group words into display lines."""
        lines = []
        for i in range(0, len(words), max_per_line):
            lines.append(words[i:i + max_per_line])
        return lines

    def generate(
        self,
        words: list[TranscriptWord],
        style: CaptionStyle,
        video_width: int = 1080,
        video_height: int = 1920,
    ) -> str:
        """Generate ASS subtitle content from word-level timestamps."""
        
        primary_color = self._hex_to_ass_color(style.primary_color)
        highlight_color = self._hex_to_ass_color(style.highlight_color)
        outline_color = self._hex_to_ass_color(style.stroke_color)
        back_color = self._hex_to_ass_color(style.shadow_color)
        
        # Alignment: 1=BottomLeft, 2=BottomCenter, 3=BottomRight, 4=MidLeft, 5=MidCenter, etc.
        alignment = 2
        if style.vertical_position == "center":
            alignment = 5
        elif style.vertical_position == "top":
            alignment = 8
            
        ass_lines = []
        # Header
        ass_lines.append("[Script Info]")
        ass_lines.append("ScriptType: v4.00+")
        ass_lines.append(f"PlayResX: {video_width}")
        ass_lines.append(f"PlayResY: {video_height}")
        ass_lines.append("WrapStyle: 1")
        ass_lines.append("")
        
        # Styles
        ass_lines.append("[V4+ Styles]")
        ass_lines.append("Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding")
        
        bold_val = "-1" if style.font_weight.lower() in ("bold", "extrabold", "black", "semibold") else "0"
        
        style_def = (
            f"Style: Default,{style.font_family},{style.font_size},{primary_color},{primary_color},"
            f"{outline_color},{back_color},{bold_val},0,0,0,100,100,0,0,1,"
            f"{style.stroke_width},{style.shadow_offset_x},{alignment},10,10,{style.margin_bottom},1"
        )
        ass_lines.append(style_def)
        ass_lines.append("")
        
        # Events
        ass_lines.append("[Events]")
        ass_lines.append("Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text")
        
        grouped_lines = self._group_words_into_lines(words, style.max_words_per_line)
        
        for line_words in grouped_lines:
            if not line_words:
                continue
            
            line_start = line_words[0].start
            line_end = line_words[-1].end
            
            if style.animation_type in ("none", "fade"):
                # Single event for the whole line
                text_parts = []
                for w in line_words:
                    word_str = w.word.upper() if style.uppercase else w.word
                    text_parts.append(word_str)
                full_text = " ".join(text_parts)
                
                start_str = self._format_time(line_start)
                end_str = self._format_time(line_end)
                ass_lines.append(f"Dialogue: 0,{start_str},{end_str},Default,,0,0,0,,{full_text}")
                
            else:
                # Word-level highlight events
                for i, active_word in enumerate(line_words):
                    event_start = active_word.start
                    # End time is start of next word, or end of current word if last in line
                    if i < len(line_words) - 1:
                        event_end = line_words[i + 1].start
                    else:
                        event_end = line_words[-1].end
                        
                    start_str = self._format_time(event_start)
                    end_str = self._format_time(event_end)
                    
                    text_parts = []
                    for j, w in enumerate(line_words):
                        word_str = w.word.upper() if style.uppercase else w.word
                        if j == i:
                            # Highlighted word
                            # We can also add \t animations here for pop effect if needed
                            if style.animation_type == "pop":
                                text_parts.append(f"{{\\1c{highlight_color}\\fscx120\\fscy120\\t(0,{style.animation_duration_ms},\\fscx100\\fscy100)}}{word_str}{{\\1c{primary_color}}}")
                            else:
                                text_parts.append(f"{{\\1c{highlight_color}}}{word_str}{{\\1c{primary_color}}}")
                        else:
                            # Normal word
                            text_parts.append(word_str)
                            
                    full_text = " ".join(text_parts)
                    ass_lines.append(f"Dialogue: 0,{start_str},{end_str},Default,,0,0,0,,{full_text}")

        return "\n".join(ass_lines)
        
    def save(self, content: str, output_path: Path) -> None:
        """Save ASS content to file."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)
