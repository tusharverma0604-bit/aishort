import asyncio
from pathlib import Path
from backend.exceptions import FFmpegError

class CaptionBurnIn:
    """Burns ASS subtitles into video using FFmpeg."""
    
    def __init__(self, ffmpeg_threads: int = 0):
        self.ffmpeg_threads = ffmpeg_threads
    
    async def burn(
        self,
        video_path: Path,
        ass_path: Path,
        output_path: Path,
    ) -> Path:
        """Burn ASS subtitles into video."""
        if not video_path.exists():
            raise FileNotFoundError(f"Video file not found: {video_path}")
        if not ass_path.exists():
            raise FileNotFoundError(f"ASS subtitle file not found: {ass_path}")
            
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # FFmpeg's ass filter fails if the path contains spaces unless heavily escaped.
        # The most robust fix is to run ffmpeg in the same directory as the .ass file.
        ass_filename = ass_path.name
        cwd = ass_path.parent
        
        cmd = [
            "ffmpeg", "-y",
            "-i", str(video_path.absolute()),
            "-vf", f"ass={ass_filename}",
            "-c:v", "h264_nvenc",
            "-preset", "p2",
            "-cq", "22",
            "-c:a", "copy",
            "-movflags", "+faststart",
        ]
        
        if self.ffmpeg_threads > 0:
            cmd.extend(["-threads", str(self.ffmpeg_threads)])
            
        cmd.append(str(output_path.absolute()))
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(cwd)
        )
        
        stdout, stderr = await process.communicate()
        
        if process.returncode != 0:
            error_msg = stderr.decode() if stderr else "Unknown FFmpeg error"
            raise FFmpegError(f"Failed to burn subtitles: {error_msg}")
            
        return output_path
