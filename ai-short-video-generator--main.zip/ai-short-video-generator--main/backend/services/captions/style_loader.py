import yaml
from dataclasses import dataclass
from pathlib import Path


@dataclass
class CaptionStyle:
    name: str
    font_family: str
    font_size: int
    font_weight: str
    primary_color: str
    highlight_color: str
    background_color: str
    stroke_color: str
    stroke_width: int
    shadow_color: str
    shadow_offset_x: int
    shadow_offset_y: int
    animation_type: str
    animation_duration_ms: int
    vertical_position: str
    margin_bottom: int
    max_words_per_line: int
    uppercase: bool


def load_caption_style(style_name: str, styles_dir: Path) -> CaptionStyle:
    """Load a caption style from YAML file."""
    yaml_path = styles_dir / f"{style_name}.yaml"
    if not yaml_path.exists():
        raise FileNotFoundError(f"Style configuration {yaml_path} not found.")

    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    return CaptionStyle(
        name=data.get("name", style_name),
        font_family=data.get("font", {}).get("family", "Arial"),
        font_size=data.get("font", {}).get("size", 48),
        font_weight=data.get("font", {}).get("weight", "Bold"),
        primary_color=data.get("color", {}).get("primary", "#FFFFFF"),
        highlight_color=data.get("color", {}).get("highlight", "#FFFF00"),
        background_color=data.get("color", {}).get("background", "transparent"),
        stroke_color=data.get("stroke", {}).get("color", "#000000"),
        stroke_width=data.get("stroke", {}).get("width", 2),
        shadow_color=data.get("shadow", {}).get("color", "transparent"),
        shadow_offset_x=data.get("shadow", {}).get("offset_x", 0),
        shadow_offset_y=data.get("shadow", {}).get("offset_y", 0),
        animation_type=data.get("animation", {}).get("type", "none"),
        animation_duration_ms=data.get("animation", {}).get("duration_ms", 0),
        vertical_position=data.get("position", {}).get("vertical", "bottom"),
        margin_bottom=data.get("position", {}).get("margin_bottom", 200),
        max_words_per_line=data.get("max_words_per_line", 4),
        uppercase=data.get("uppercase", False),
    )


def list_caption_styles(styles_dir: Path) -> list[str]:
    """List all available caption style names."""
    if not styles_dir.exists():
        return []
    return [p.stem for p in styles_dir.glob("*.yaml")]
