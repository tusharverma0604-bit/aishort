import asyncio
import logging
from pathlib import Path

from backend.models.project import ViralClipCandidate
from backend.exceptions import FFmpegError

logger = logging.getLogger(__name__)

class ClipCutter:
    """Cuts clips from source video using FFmpeg."""
    
    def __init__(self, ffmpeg_threads: int = 0):
        self.ffmpeg_threads = ffmpeg_threads
    
    async def cut_clip(
        self,
        source_video: Path,
        output_path: Path,
        start_time: float,
        end_time: float,
    ) -> Path:
        """Cut a clip from source video using FFmpeg.
        
        Uses fast seek approach: ffmpeg -ss start -i input -t duration -c:v libx264 -preset fast -crf 18 -c:a aac output
        re-encoding for frame accuracy.
        """
        duration = end_time - start_time
        if duration <= 0:
            raise ValueError("end_time must be greater than start_time")
        
        cmd = [
            "ffmpeg",
            "-y",
            "-ss", str(start_time),
            "-i", str(source_video),
            "-t", str(duration),
            "-c:v", "h264_nvenc",
            "-preset", "p2",
            "-cq", "22",
            "-c:a", "aac",
            "-af", "aresample=async=1",
            "-vsync", "1",
            "-avoid_negative_ts", "make_zero",
            "-movflags", "+faststart",
        ]
        
        if self.ffmpeg_threads > 0:
            cmd.extend(["-threads", str(self.ffmpeg_threads)])
            
        cmd.append(str(output_path))
        
        logger.info(f"Cutting clip from {source_video} to {output_path} ({start_time} to {end_time})")
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        
        stdout, stderr = await process.communicate()
        
        if process.returncode != 0:
            logger.error(f"FFmpeg failed with return code {process.returncode}")
            logger.error(f"FFmpeg stderr: {stderr.decode()}")
            raise FFmpegError(f"Failed to cut clip: {stderr.decode()}")
            
        return output_path

    async def cut_multiple(
        self,
        source_video: Path,
        clips: list[ViralClipCandidate],
        output_dir: Path,
        max_parallel: int = 4,
    ) -> list[Path]:
        """Cut multiple clips in parallel using asyncio.gather with semaphore."""
        output_dir.mkdir(parents=True, exist_ok=True)
        semaphore = asyncio.Semaphore(max_parallel)
        
        async def _cut_with_semaphore(clip: ViralClipCandidate, index: int) -> Path:
            async with semaphore:
                output_path = output_dir / f"clip_{index}_{clip.start_time:.1f}_{clip.end_time:.1f}.mp4"
                return await self.cut_clip(
                    source_video,
                    output_path,
                    clip.start_time,
                    clip.end_time
                )
                
        tasks = [
            _cut_with_semaphore(clip, i)
            for i, clip in enumerate(clips)
        ]
        
        results = await asyncio.gather(*tasks)
        return list(results)
