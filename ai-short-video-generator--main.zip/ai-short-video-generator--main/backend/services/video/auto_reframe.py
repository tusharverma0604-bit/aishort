"""Auto-reframe: converts landscape video to 9:16 portrait with active speaker tracking.

Uses step-function crop positions (hard jump cuts) to follow the active speaker.
No panning, no sliding — the crop window teleports instantly when the speaker changes.
"""

import asyncio
import logging
from pathlib import Path

from backend.exceptions import FFmpegError
from backend.services.video.face_detector import FaceDetector, FaceTimeline

logger = logging.getLogger(__name__)


class AutoReframer:
    """Auto-reframes landscape video to 9:16 portrait with active speaker tracking.

    All reframe modes use temporal lip-delta face detection to center on the speaker:
    - crop: Dynamically crops a 9:16 window centered on the active speaker
    - blur: Full frame with blurred side panels, centered on speaker
    - pad: Full frame with black side bars, centered on speaker

    Camera uses hard jump cuts (step function) — no panning or sliding transitions.
    """

    def __init__(self, face_detector: FaceDetector, ffmpeg_threads: int = 0):
        self.face_detector = face_detector
        self.ffmpeg_threads = ffmpeg_threads

    async def reframe(
        self,
        input_path: Path,
        output_path: Path,
        start_time: float = 0.0,
        end_time: float = 0.0,
        mode: str = "crop",
        zoom_start: float | None = None,
        zoom_end: float | None = None,
        target_width: int = 1080,
        target_height: int = 1920,
    ) -> tuple[Path, list[float]]:
        """Reframe video to 9:16 portrait with active speaker tracking.

        1. Build active-speaker timeline (temporal lip-delta at 5 fps)
        2. Generate FFmpeg filter with step-function crop positions
        3. Encode with GPU (h264_nvenc), fallback to libx264
        """
        import cv2

        cap = cv2.VideoCapture(str(input_path))
        if not cap.isOpened():
            raise ValueError(f"Could not open video {input_path}")

        video_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        video_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        cap.release()

        if fps <= 0:
            fps = 30.0
        if end_time <= 0.0 and total_frames > 0:
            end_time = total_frames / fps

        # Step 1: Build active-speaker timeline
        if mode in ("blur", "pad"):
            logger.info(f"[AutoReframe] Mode={mode} requires no face tracking.")
            timeline = None
            timelines = [None, None, None]
        else:
            logger.info(f"[AutoReframe] Building face timelines for {input_path.name}...")
            timelines = await self.face_detector.build_face_timeline(
                video_path=input_path,
                start_time=start_time,
                end_time=end_time,
                sample_fps=5.0,
            )
            timeline = timelines[0]

        # Podcast mode disabled by user request (defaults to normal face tracking)
        if mode == "podcast":
            logger.info("[AutoReframe] mode=podcast disabled by user. Falling back to mode=crop.")
            mode = "crop"

        # Step 2: Build FFmpeg filter based on mode
        if mode == "blur":
            vf_filter = self._build_blur_filter(
                timeline, video_width, video_height, target_width, target_height, fps
            )
        elif mode == "pad":
            vf_filter = self._build_pad_filter(
                timeline, video_width, video_height, target_width, target_height, fps
            )
        elif mode == "split":
            vf_filter = self._build_split_filter(
                timeline, video_width, video_height, target_width, target_height, fps
            )
        elif mode == "podcast":
            vf_filter = self._build_podcast_filter(
                timeline, timelines[1], timelines[2], video_width, video_height, target_width, target_height, fps
            )
        else:
            vf_filter = self._build_crop_filter(
                timeline, video_width, video_height, target_width, target_height, fps
            )

        # Note: zoompan filter removed — it caused 100x slowdown (frame-by-frame CPU processing)
        # The crop filter already provides excellent reframing with face tracking

        positions_count = len(timeline.keyframes) if timeline and timeline.keyframes else 0
        logger.info(
            f"[AutoReframe] Reframing {input_path.name} → {output_path.name} "
            f"mode={mode}, {positions_count} step-cut positions"
        )

        # Step 3: GPU encode with fallback
        await self._encode_with_fallback(input_path, output_path, vf_filter)

        cut_timestamps = [kf.timestamp for kf in timeline.keyframes if kf.is_hard_cut] if timeline and timeline.keyframes else []

        return output_path, cut_timestamps

    # ────────────────────── Encoding ──────────────────────

    async def _encode_with_fallback(
        self,
        input_path: Path,
        output_path: Path,
        vf_filter: str,
    ) -> None:
        """Run FFmpeg encoding with GPU (h264_nvenc), fallback to CPU (libx264).
        
        Includes a 10-minute timeout to prevent infinite hangs.
        """
        TIMEOUT = 600  # 10 minutes max per clip

        # Try GPU encoding first
        cmd_gpu = [
            "ffmpeg", "-y",
            "-i", str(input_path),
            "-vf", vf_filter,
            "-c:v", "h264_nvenc",
            "-preset", "p2",
            "-cq", "22",
            "-c:a", "aac",
            "-af", "aresample=async=1",
            "-vsync", "1",
            "-movflags", "+faststart",
        ]
        if self.ffmpeg_threads > 0:
            cmd_gpu.extend(["-threads", str(self.ffmpeg_threads)])
        cmd_gpu.append(str(output_path))

        logger.info("[AutoReframe] Encoding with GPU (h264_nvenc)...")

        process = await asyncio.create_subprocess_exec(
            *cmd_gpu,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=TIMEOUT)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            logger.error(f"[AutoReframe] GPU encoding timed out after {TIMEOUT}s")
            raise FFmpegError(f"FFmpeg encoding timed out after {TIMEOUT}s")

        if process.returncode == 0:
            logger.info("[AutoReframe] GPU encoding complete ✓")
            return

        # GPU failed — try CPU fallback
        stderr_gpu = stderr.decode()[-300:]
        logger.warning(
            f"[AutoReframe] GPU encoding failed (rc={process.returncode}): "
            f"{stderr_gpu}. Falling back to CPU (libx264)..."
        )

        cmd_cpu = [
            "ffmpeg", "-y",
            "-i", str(input_path),
            "-vf", vf_filter,
            "-c:v", "libx264",
            "-preset", "fast",
            "-crf", "22",
            "-c:a", "aac",
            "-af", "aresample=async=1",
            "-vsync", "1",
            "-movflags", "+faststart",
        ]
        if self.ffmpeg_threads > 0:
            cmd_cpu.extend(["-threads", str(self.ffmpeg_threads)])
        cmd_cpu.append(str(output_path))

        process = await asyncio.create_subprocess_exec(
            *cmd_cpu,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=TIMEOUT)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            logger.error(f"[AutoReframe] CPU encoding timed out after {TIMEOUT}s")
            raise FFmpegError(f"FFmpeg encoding timed out after {TIMEOUT}s")

        if process.returncode != 0:
            stderr_text = stderr.decode()
            logger.error(
                f"[AutoReframe] CPU encoding also failed (rc={process.returncode}): "
                f"{stderr_text[-500:]}"
            )
            raise FFmpegError(f"Failed to reframe video: {stderr_text}")

        logger.info("[AutoReframe] CPU encoding complete ✓ (GPU was unavailable)")

    # ────────────────────── Filter Builders ──────────────────────

    def _build_crop_filter(
        self,
        timeline: FaceTimeline,
        video_width: int,
        video_height: int,
        target_width: int,
        target_height: int,
        fps: float,
    ) -> str:
        """Build FFmpeg crop filter with step-function speaker positions."""
        target_aspect = target_width / target_height

        crop_h = video_height
        crop_w = int(crop_h * target_aspect)
        if crop_w > video_width:
            crop_w = video_width
            crop_h = int(crop_w / target_aspect)

        crop_w = crop_w - (crop_w % 2)
        crop_h = crop_h - (crop_h % 2)

        if not timeline.keyframes:
            crop_x = max(0, (video_width - crop_w) // 2)
            crop_y = max(0, (video_height - crop_h) // 2)
            return (
                f"crop={crop_w}:{crop_h}:{crop_x}:{crop_y},"
                f"scale={target_width}:{target_height}"
            )

        crop_x_expr = self._build_step_expr(
            timeline, fps, "x", crop_w, video_width, crop_w // 2
        )
        crop_y_expr = self._build_step_expr(
            timeline, fps, "y", crop_h, video_height, crop_h // 2
        )

        return (
            f"crop={crop_w}:{crop_h}:{crop_x_expr}:{crop_y_expr},"
            f"scale={target_width}:{target_height}"
        )

    def _build_blur_filter(
        self,
        timeline: FaceTimeline | None,
        video_width: int,
        video_height: int,
        target_width: int,
        target_height: int,
        fps: float,
    ) -> str:
        """Build blur-background filter. No face tracking required; fits the whole video over a blurred background."""
        return (
            f"split=2[bg][fg];"
            f"[bg]scale={target_width}:{target_height}:force_original_aspect_ratio=increase,"
            f"crop={target_width}:{target_height}:(iw-ow)/2:(ih-oh)/2,boxblur=20:20,setsar=1[b];"
            f"[fg]scale={target_width}:{target_height}:force_original_aspect_ratio=decrease,setsar=1[f];"
            f"[b][f]overlay=(W-w)/2:(H-h)/2"
        )

    def _build_pad_filter(
        self,
        timeline: FaceTimeline | None,
        video_width: int,
        video_height: int,
        target_width: int,
        target_height: int,
        fps: float,
    ) -> str:
        """Build pad (black bars) filter. No face tracking required; fits the whole video."""
        return (
            f"scale={target_width}:{target_height}:force_original_aspect_ratio=decrease,"
            f"pad={target_width}:{target_height}:(ow-iw)/2:(oh-ih)/2:black,setsar=1"
        )

    def _build_split_filter(
        self,
        timeline: FaceTimeline,
        video_width: int,
        video_height: int,
        target_width: int,
        target_height: int,
        fps: float,
    ) -> str:
        """Build 50/50 split-screen filter for streamer reaction / gaming videos.

        Top half (1080x960): High-resolution center crop of the main gameplay/screen.
        Bottom half (1080x960): Active speaker tracking crop zoomed on the streamer's reaction webcam/face.
        """
        half_height = target_height // 2
        target_aspect = target_width / half_height

        # Calculate crop dimensions for 9:8 half-screen aspect ratio
        crop_h = video_height
        crop_w = int(crop_h * target_aspect)
        if crop_w > video_width:
            crop_w = video_width
            crop_h = int(crop_w / target_aspect)

        crop_w = crop_w - (crop_w % 2)
        crop_h = crop_h - (crop_h % 2)

        # Top half: Center of gameplay
        top_crop_x = max(0, (video_width - crop_w) // 2)
        top_crop_y = max(0, (video_height - crop_h) // 2)

        # Bottom half: Streamer face tracking
        if not timeline.keyframes:
            bot_crop_x = str(top_crop_x)
            bot_crop_y = str(top_crop_y)
            return (
                f"split=2[game][webcam];"
                f"[game]crop={crop_w}:{crop_h}:{top_crop_x}:{top_crop_y},"
                f"scale={target_width}:{half_height},setsar=1[top];"
                f"[webcam]crop={crop_w}:{crop_h}:{bot_crop_x}:{bot_crop_y},"
                f"scale={target_width}:{half_height},setsar=1[bottom];"
                f"[top][bottom]vstack=inputs=2"
            )

        bot_crop_x_expr = self._build_step_expr(
            timeline, fps, "x", crop_w, video_width, crop_w // 2
        )
        bot_crop_y_expr = self._build_step_expr(
            timeline, fps, "y", crop_h, video_height, crop_h // 2
        )

        return (
            f"split=2[game][webcam];"
            f"[game]crop={crop_w}:{crop_h}:{top_crop_x}:{top_crop_y},"
            f"scale={target_width}:{half_height},setsar=1[top];"
            f"[webcam]crop={crop_w}:{crop_h}:{bot_crop_x_expr}:{bot_crop_y_expr},"
            f"scale={target_width}:{half_height},setsar=1[bottom];"
            f"[top][bottom]vstack=inputs=2"
        )

    def _build_podcast_filter(
        self,
        timeline: FaceTimeline,
        host_timeline: FaceTimeline,
        guest_timeline: FaceTimeline,
        video_width: int,
        video_height: int,
        target_width: int,
        target_height: int,
        fps: float,
    ) -> str:
        """Build a podcast filter with dynamic fallback to full-frame for single speakers."""
        half_height = target_height // 2
        target_aspect = target_width / half_height

        crop_h = video_height
        crop_w = int(crop_h * target_aspect)
        if crop_w > video_width:
            crop_w = video_width
            crop_h = int(crop_w / target_aspect)

        crop_w = crop_w - (crop_w % 2)
        crop_h = crop_h - (crop_h % 2)

        # Build dynamic expressions for host
        top_crop_x_expr = self._build_step_expr(
            host_timeline, fps, "x", crop_w, video_width, crop_w // 2
        )
        top_crop_y_expr = self._build_step_expr(
            host_timeline, fps, "y", crop_h, video_height, crop_h // 2
        )

        # Build dynamic expressions for guest
        bot_crop_x_expr = self._build_step_expr(
            guest_timeline, fps, "x", crop_w, video_width, crop_w // 2
        )
        bot_crop_y_expr = self._build_step_expr(
            guest_timeline, fps, "y", crop_h, video_height, crop_h // 2
        )

        # --- FULL FRAME LOGIC ---
        full_target_aspect = target_width / target_height
        full_crop_h = video_height
        full_crop_w = int(full_crop_h * full_target_aspect)
        if full_crop_w > video_width:
            full_crop_w = video_width
            full_crop_h = int(full_crop_w / full_target_aspect)

        full_crop_w = full_crop_w - (full_crop_w % 2)
        full_crop_h = full_crop_h - (full_crop_h % 2)

        full_crop_x_expr = self._build_step_expr(timeline, fps, "x", full_crop_w, video_width, full_crop_w // 2)
        full_crop_y_expr = self._build_step_expr(timeline, fps, "y", full_crop_h, video_height, full_crop_h // 2)

        # Determine segments where we should fallback to full frame.
        # We only split the screen if the two speakers are PHYSICALLY SEPARATED on screen
        # (e.g. a wide shot where one is on the left and one is on the right).
        # If they are close together (or it's a single-person cut where both default to the center),
        # we MUST use full frame to avoid showing the same person on top and bottom.
        enable_exprs = []
        start_ts = None
        for kf in timeline.keyframes:
            host_x, _ = host_timeline.get_position_at(kf.timestamp)
            guest_x, _ = guest_timeline.get_position_at(kf.timestamp)
            
            # Distance between the two faces in the original video
            face_distance = abs(host_x - guest_x)
            
            # If they are closer than 15% of the video width, they are likely the same person 
            # (or it's a single person cut where both timelines track the center)
            is_single_person_shot = face_distance < (video_width * 0.15)
            
            if is_single_person_shot:
                if start_ts is None:
                    start_ts = kf.timestamp
            else:
                if start_ts is not None:
                    enable_exprs.append(f"between(t,{start_ts},{kf.timestamp})")
                    start_ts = None
                    
        if start_ts is not None:
            enable_exprs.append(f"gt(t,{start_ts})")

        enable_full_expr = "+".join(enable_exprs) if enable_exprs else "0"

        return (
            f"split=3[left][right][full];"
            f"[left]crop={crop_w}:{crop_h}:{top_crop_x_expr}:{top_crop_y_expr},"
            f"scale={target_width}:{half_height},setsar=1[top];"
            f"[right]crop={crop_w}:{crop_h}:{bot_crop_x_expr}:{bot_crop_y_expr},"
            f"scale={target_width}:{half_height},setsar=1[bottom];"
            f"[top][bottom]vstack=inputs=2[split];"
            f"[full]crop={full_crop_w}:{full_crop_h}:{full_crop_x_expr}:{full_crop_y_expr},"
            f"scale={target_width}:{target_height},setsar=1[full_scaled];"
            f"[split][full_scaled]overlay=enable='{enable_full_expr}'"
        )

    # ────────────────────── Step Expression Builder ──────────────────────

    def _build_step_expr(
        self,
        timeline: FaceTimeline,
        fps: float,
        axis: str,
        crop_size: int,
        video_size: int,
        half_crop: int,
    ) -> str:
        """Build an FFmpeg step-function expression for crop position.

        Unlike linear interpolation, this holds each position constant until
        the next keyframe, then jumps instantly. Result:
            if(lt(n,f1), pos0, if(lt(n,f2), pos1, pos2))

        Because keyframes are already collapsed (consecutive identical positions
        merged), the expression is typically only 5-20 segments instead of 200+.
        """
        if not timeline.keyframes:
            return str(max(0, video_size // 2 - half_crop))

        # Convert keyframes to (frame_number, clamped_crop_position, is_hard_cut) tuples
        segments: list[tuple[int, int, bool]] = []
        for kf in timeline.keyframes:
            frame_num = int(kf.timestamp * fps)
            if axis == "x":
                pos = kf.center_x - half_crop
            else:
                pos = kf.center_y - half_crop
            pos = max(0, min(pos, video_size - crop_size))
            is_hard = getattr(kf, "is_hard_cut", True)
            segments.append((frame_num, pos, is_hard))

        if not segments:
            return str(max(0, video_size // 2 - half_crop))

        # Deduplicate consecutive identical positions and cut types
        deduped: list[tuple[int, int, bool]] = [segments[0]]
        for frame_num, pos, is_hard in segments[1:]:
            if pos != deduped[-1][1] or is_hard != deduped[-1][2]:
                deduped.append((frame_num, pos, is_hard))
        segments = deduped

        if len(segments) == 1:
            return str(segments[0][1])

        # Safety: cap at 80 segments to avoid FFmpeg expression parser limits
        if len(segments) > 80:
            logger.warning(
                f"[AutoReframe] {axis}-axis has {len(segments)} segments, "
                f"capping at 80 to avoid FFmpeg expression limits"
            )
            step = len(segments) / 80
            capped = [segments[int(i * step)] for i in range(80)]
            capped.append(segments[-1])
            segments = capped

        logger.debug(
            f"[AutoReframe] {axis}-axis hybrid expression: {len(segments)} segments"
        )

        # Build nested if() expression (hybrid step/pan function)
        expr = self._build_nested_step(segments)
        return expr.replace(",", "\\,")

    @staticmethod
    def _build_nested_step(segments: list[tuple[int, int, bool]]) -> str:
        """Build a hybrid if() expression supporting both hard jump cuts and smooth panning.

        - When cutting to a new speaker (is_hard_cut == True), holds position constant until frame_end (step function).
        - When tracking the same speaker moving outside the deadzone (is_hard_cut == False), applies linear interpolation (smooth pan).
        """
        if len(segments) <= 1:
            return str(segments[0][1] if segments else 0)

        # Build from the end
        result = str(segments[-1][1])

        for i in range(len(segments) - 2, -1, -1):
            f_start, p_start, _ = segments[i]
            f_end, p_next, is_hard_next = segments[i + 1]
            
            if is_hard_next or p_start == p_next:
                # Hard jump cut at f_end: hold p_start constant during this segment
                seg_expr = str(p_start)
            else:
                # Smooth pan: interpolate linearly from p_start to p_next between f_start and f_end
                duration = max(1, f_end - f_start)
                seg_expr = f"{p_start}+({p_next}-{p_start})*(n-{f_start})/{duration}"
                
            result = f"if(lt(n,{f_end}),{seg_expr},{result})"

        return result
