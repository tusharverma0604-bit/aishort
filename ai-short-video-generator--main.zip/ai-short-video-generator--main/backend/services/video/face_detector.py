"""Active speaker detection with temporal lip-delta tracking.

Detects WHO is talking in multi-person video by measuring lip movement
ACROSS consecutive frames (not single-frame mouth openness).

Pipeline:
  FFmpeg GPU frame extraction → MediaPipe Face Mesh per frame →
  Persistent face ID tracking across frames → Lip-delta scoring →
  Active speaker selection → Step-function crop keyframes (hard jumps)

When MediaPipe is unavailable, falls back to SIZE-BASED tracking:
  Uses OpenCV cascades → tracks largest face → switches on significant
  size changes (assumes largest face = main speaker on camera).
"""

import asyncio
import logging
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import numpy as np

logger = logging.getLogger(__name__)

__all__ = ["FaceDetector", "FaceTimeline", "FaceRegion", "FaceKeyframe"]

# MediaPipe Face Mesh landmark indices for lip tracking
# Inner lip ring — these move the most during speech
_LIP_LANDMARKS = [
    13,   # upper lip center
    14,   # lower lip center
    78,   # left inner lip corner
    308,  # right inner lip corner
    82,   # upper lip left
    312,  # upper lip right
    87,   # lower lip left
    317,  # lower lip right
]


@dataclass
class FaceRegion:
    x: int
    y: int
    w: int
    h: int
    confidence: float
    # Raw lip landmark positions (y-coords) for temporal delta computation
    lip_landmarks: list[float] = field(default_factory=list)


@dataclass
class FaceKeyframe:
    """A single face position at a specific timestamp."""
    timestamp: float
    center_x: int
    center_y: int
    width: int
    height: int
    confidence: float
    speaker_id: int = -1
    lip_delta: float = 0.0
    is_hard_cut: bool = True  # True = hard jump cut (speaker switch), False = smooth pan (same speaker movement)
    num_faces: int = 1


@dataclass
class FaceTimeline:
    """Step-function timeline of active speaker positions for hard-cut reframing."""
    keyframes: list[FaceKeyframe] = field(default_factory=list)
    video_width: int = 0
    video_height: int = 0
    fps: float = 30.0

    def get_position_at(self, timestamp: float) -> tuple[int, int]:
        """Get the active speaker's center (x, y) at a given timestamp.

        Uses step-function lookup (no interpolation) — returns the position
        of the most recent keyframe.
        """
        if not self.keyframes:
            return self.video_width // 2, self.video_height // 2

        # Before first keyframe
        if timestamp <= self.keyframes[0].timestamp:
            return self.keyframes[0].center_x, self.keyframes[0].center_y

        # Find the last keyframe at or before this timestamp (step function)
        result = self.keyframes[0]
        for kf in self.keyframes:
            if kf.timestamp <= timestamp:
                result = kf
            else:
                break

        return result.center_x, result.center_y


# ─────────────────────────────────────────────────────────────────
#  Tracked face: persistent identity across frames
# ─────────────────────────────────────────────────────────────────

@dataclass
class _TrackedFace:
    """Internal: a face tracked across multiple consecutive frames."""
    face_id: int
    center_x: int
    center_y: int
    width: int
    height: int
    confidence: float
    # Lip landmark positions from the PREVIOUS frame (for delta computation)
    prev_lip_landmarks: list[float] = field(default_factory=list)
    # Accumulated lip-delta over a rolling window
    lip_delta_history: list[float] = field(default_factory=list)
    # How many consecutive frames this face has been tracked
    frames_seen: int = 0
    # Last timestamp this face was seen
    last_seen_ts: float = 0.0


class FaceDetector:
    """Active speaker detector using temporal lip-delta analysis.

    Instead of measuring lip openness on a single frame (unreliable),
    measures how much lip landmarks MOVE between consecutive frames.
    Only active speech produces continuous rapid lip movement.

    When MediaPipe is not available, falls back to SIZE-BASED tracking:
    picks the largest face as the main subject, with appropriate switching
    logic that follows the most prominent person on screen.
    """

    _LIP_DELTA_WINDOW = 5          # Rolling window size for lip-delta averaging
    _LIP_DELTA_SPEECH_THRESHOLD = 3.0   # Min avg lip-delta to be considered speaking
    _SPEAKER_SWITCH_THRESHOLD = 8       # Frames new speaker must dominate before switching
    _SAMPLE_FPS = 5.0              # Frames per second to sample (higher = better accuracy)

    def __init__(self) -> None:
        import cv2  # type: ignore

        self.use_mediapipe = False
        self._mp_face_mesh: Any = None

        # Try multiple MediaPipe import strategies
        self._init_mediapipe()

        # OpenCV cascades as fallback (no lip tracking possible)
        cv2_data: Any = getattr(cv2, "data", None)
        haarcascades_dir = str(getattr(cv2_data, "haarcascades", "")) if cv2_data else ""

        self.frontal_cascade = cv2.CascadeClassifier(
            haarcascades_dir + "haarcascade_frontalface_default.xml"
        )
        self.profile_cascade = cv2.CascadeClassifier(
            haarcascades_dir + "haarcascade_profileface.xml"
        )
        self.upperbody_cascade = cv2.CascadeClassifier(
            haarcascades_dir + "haarcascade_upperbody.xml"
        )

    def _init_mediapipe(self) -> None:
        """Try multiple MediaPipe import strategies for different versions."""
        last_err = "Unknown import error"
        try:
            import mediapipe as mp  # type: ignore
            face_mesh_mod = None

            # Strategy 1: mp.solutions.face_mesh (works in most versions)
            try:
                face_mesh_mod = mp.solutions.face_mesh  # type: ignore
                logger.debug("MediaPipe: found via mp.solutions.face_mesh")
            except Exception as e:
                last_err = f"mp.solutions.face_mesh failed ({e})"

            # Strategy 2: direct import mediapipe.solutions.face_mesh
            if face_mesh_mod is None:
                try:
                    import mediapipe.solutions.face_mesh as fm0  # type: ignore
                    face_mesh_mod = fm0
                    logger.debug("MediaPipe: found via import mediapipe.solutions.face_mesh")
                except Exception as e:
                    last_err = f"import mediapipe.solutions.face_mesh failed ({e})"

            # Strategy 3: from mediapipe.python.solutions import face_mesh
            if face_mesh_mod is None:
                try:
                    from mediapipe.python.solutions import face_mesh as fm  # type: ignore
                    face_mesh_mod = fm
                    logger.debug("MediaPipe: found via mediapipe.python.solutions.face_mesh")
                except Exception as e:
                    last_err = f"mediapipe.python.solutions failed ({e})"

            # Strategy 4: from mediapipe.solutions import face_mesh
            if face_mesh_mod is None:
                try:
                    from mediapipe.solutions import face_mesh as fm2  # type: ignore
                    face_mesh_mod = fm2
                    logger.debug("MediaPipe: found via mediapipe.solutions.face_mesh")
                except Exception as e:
                    last_err = f"from mediapipe.solutions failed ({e})"

            if face_mesh_mod is not None:
                self._mp_face_mesh = face_mesh_mod.FaceMesh(
                    static_image_mode=True,
                    max_num_faces=10,
                    refine_landmarks=True,
                    min_detection_confidence=0.25,
                )
                self.use_mediapipe = True
                logger.info(
                    "FaceDetector: MediaPipe Face Mesh initialized "
                    "(lip-delta temporal speaker tracking enabled)"
                )
                return
            else:
                logger.warning(f"MediaPipe installed but face_mesh module could not be loaded: {last_err}")

        except ImportError as exc:
            logger.warning(f"MediaPipe not installed ({exc}).")
        except Exception as exc:
            logger.warning(f"MediaPipe initialization failed: {exc}")

        logger.warning(
            "⚠️  MediaPipe Face Mesh NOT available — using SIZE-BASED face tracking. "
            "For neural tracking, install: pip install 'mediapipe==0.10.14'"
        )

    # ─────────────────────────────────────────────────────────────
    #  Per-frame face detection
    # ─────────────────────────────────────────────────────────────

    def detect_faces(self, frame: "np.ndarray") -> list[FaceRegion]:
        """Detect faces in a single frame with raw lip landmark positions.

        Returns list of FaceRegion with lip_landmarks populated for
        temporal delta computation across frames.
        """
        import cv2  # type: ignore

        h, w = frame.shape[:2]
        regions: list[FaceRegion] = []

        # 1. MediaPipe Face Mesh (preferred — gives lip landmarks)
        if self.use_mediapipe and self._mp_face_mesh is not None:
            try:
                rgb = cv2.cvtColor(frame, getattr(cv2, "COLOR_BGR2RGB", 4))
                results = self._mp_face_mesh.process(rgb)

                if results and getattr(results, "multi_face_landmarks", None):
                    for landmarks in results.multi_face_landmarks:
                        # Bounding box from all landmarks
                        xs = [lm.x * w for lm in landmarks.landmark]
                        ys = [lm.y * h for lm in landmarks.landmark]
                        min_x = max(0, int(min(xs)))
                        max_x = min(w, int(max(xs)))
                        min_y = max(0, int(min(ys)))
                        max_y = min(h, int(max(ys)))
                        bw = max_x - min_x
                        bh = max_y - min_y

                        # Extract raw lip landmark coordinates for delta tracking
                        lip_coords: list[float] = []
                        for idx in _LIP_LANDMARKS:
                            lm = landmarks.landmark[idx]
                            lip_coords.append(lm.x * w)
                            lip_coords.append(lm.y * h)

                        if bw > 15 and bh > 15:
                            regions.append(FaceRegion(
                                x=min_x, y=min_y, w=bw, h=bh,
                                confidence=0.95,
                                lip_landmarks=lip_coords,
                            ))

                    if regions:
                        return regions
            except Exception as e:
                logger.debug(f"Face Mesh failed: {e}")

        # 2. OpenCV Haar cascade fallback (no lip landmarks)
        gray = cv2.cvtColor(frame, getattr(cv2, "COLOR_BGR2GRAY", 6))

        faces = self.frontal_cascade.detectMultiScale(
            gray, scaleFactor=1.1, minNeighbors=4, minSize=(25, 25)
        )
        if len(faces) == 0:
            faces = self.profile_cascade.detectMultiScale(
                gray, scaleFactor=1.1, minNeighbors=3, minSize=(25, 25)
            )
        if len(faces) == 0:
            faces = self.upperbody_cascade.detectMultiScale(
                gray, scaleFactor=1.1, minNeighbors=3, minSize=(50, 50)
            )

        for bx, by, bw, bh in faces:
            regions.append(FaceRegion(
                x=int(bx), y=int(by), w=int(bw), h=int(bh),
                confidence=0.8, lip_landmarks=[],
            ))

        return regions

    # ─────────────────────────────────────────────────────────────
    #  Face timeline builder (public API)
    # ─────────────────────────────────────────────────────────────

    async def build_face_timeline(
        self,
        video_path: Path,
        start_time: float = 0.0,
        end_time: float = 0.0,
        sample_fps: float = 5.0,
    ) -> list[FaceTimeline]:
        """Build a step-function timeline of active speaker positions.

        Public API that runs the full 4-phase pipeline:
        1. Extract frames at sample_fps using FFmpeg (GPU if available)
        2. Run face detection on each frame
        3. Track identities + compute lip-deltas (or use size fallback)
        4. Collapse to step-function keyframes for FFmpeg crop expressions
        """
        return await asyncio.get_event_loop().run_in_executor(
            None,
            self._build_face_timeline_sync,
            video_path, start_time, end_time, sample_fps,
        )

    def _build_face_timeline_sync(
        self,
        video_path: Path,
        start_time: float,
        end_time: float,
        sample_fps: float,
    ) -> list[FaceTimeline]:
        """Synchronous implementation of the face timeline builder."""
        import cv2  # type: ignore

        # Get video info
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            logger.error(f"Failed to open video: {video_path}")
            return [FaceTimeline()]

        video_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        video_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        video_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        cap.release()

        if end_time <= 0 and total_frames > 0:
            end_time = total_frames / video_fps

        duration = end_time - start_time
        if duration <= 0:
            return [FaceTimeline(
                video_width=video_width, video_height=video_height, fps=video_fps
            )]

        n_frames = int(duration * sample_fps) + 1

        # ── Phase 1: GPU-accelerated frame extraction ──
        logger.info(
            f"[Speaker Tracker] Phase 1: Extracting {n_frames} frames from "
            f"{video_path.name} at {sample_fps} fps ({duration:.1f}s) using GPU..."
        )

        frames = self._extract_frames_ffmpeg(
            video_path, start_time, end_time, sample_fps, n_frames
        )

        logger.info(f"[Speaker Tracker] Phase 1 complete: {len(frames)} frames extracted")

        if not frames:
            return [FaceTimeline(
                video_width=video_width, video_height=video_height, fps=video_fps
            )]

        # ── Phase 2: Face detection with lip tracking ──
        logger.info("[Speaker Tracker] Phase 2: Running face detection with lip tracking...")

        frame_detections: list[tuple[float, list[FaceRegion]]] = []
        frames_with_faces = 0

        for i, frame in enumerate(frames):
            ts = start_time + (i / sample_fps)
            faces = self.detect_faces(frame)
            frame_detections.append((ts, faces))
            if faces:
                frames_with_faces += 1

        face_pct = (frames_with_faces * 100 // len(frames)) if frames else 0
        logger.info(
            f"[Speaker Tracker] Phase 2 complete: faces in "
            f"{frames_with_faces}/{len(frames)} frames ({face_pct}%)"
        )

        if frames_with_faces == 0:
            logger.warning(
                "[Speaker Tracker] No faces detected — using center crop"
            )
            return [FaceTimeline(
                video_width=video_width, video_height=video_height, fps=video_fps
            )]

        # ── Detect if lip tracking is available ──
        has_lip_tracking = self.use_mediapipe and any(
            any(face.lip_landmarks for face in faces)
            for _, faces in frame_detections
            if faces
        )

        if has_lip_tracking:
            logger.info("[Speaker Tracker] Phase 3: Using LIP-DELTA speaker tracking (MediaPipe active)")
        else:
            logger.info(
                "[Speaker Tracker] Phase 3: Using SIZE-BASED speaker tracking "
                "(MediaPipe unavailable — tracking largest/most prominent face)"
            )

        # ── Phase 3: Track face identities + select speaker ──
        raw_keyframes, person_keyframes = self._track_speakers_and_build_keyframes(
            frame_detections, video_width, video_height, has_lip_tracking
        )

        if not raw_keyframes:
            logger.warning("[Speaker Tracker] Speaker tracking produced no keyframes — center crop")
            return [FaceTimeline(
                video_width=video_width, video_height=video_height, fps=video_fps
            )]

        # ── Phase 4: Process hybrid camera trajectory (Deadzone + Smooth Pan + Hard Cut) ──
        collapsed = self._collapse_to_steps(raw_keyframes, video_width, video_height)

        timelines = [
            FaceTimeline(
                keyframes=collapsed,
                video_width=video_width,
                video_height=video_height,
                fps=video_fps,
            )
        ]

        logger.info(
            f"[Speaker Tracker] Done primary: {len(collapsed)} step-cut keyframes "
            f"(from {len(raw_keyframes)} raw), "
            f"x=[{min(k.center_x for k in collapsed)}-{max(k.center_x for k in collapsed)}], "
            f"y=[{min(k.center_y for k in collapsed)}-{max(k.center_y for k in collapsed)}]"
        )

        # Generate individual tracking timelines for the top 2 speakers
        top_ids = sorted(
            person_keyframes.keys(), 
            key=lambda fid: len(person_keyframes[fid]), 
            reverse=True
        )[:2]
        
        for fid in top_ids:
            collapsed_person = self._collapse_to_steps(person_keyframes[fid], video_width, video_height)
            timelines.append(FaceTimeline(
                keyframes=collapsed_person,
                video_width=video_width,
                video_height=video_height,
                fps=video_fps,
            ))
            logger.info(f"[Speaker Tracker] Built individual timeline for person#{fid} ({len(collapsed_person)} steps)")

        return timelines

    # ─────────────────────────────────────────────────────────────
    #  Phase 3: Speaker tracking (lip-delta or size-based fallback)
    # ─────────────────────────────────────────────────────────────

    def _track_speakers_and_build_keyframes(
        self,
        frame_detections: list[tuple[float, list[FaceRegion]]],
        video_width: int,
        video_height: int,
        has_lip_tracking: bool,
    ) -> tuple[list[FaceKeyframe], dict[int, list[FaceKeyframe]]]:
        """Track face identities across frames and select active speaker.

        Two modes:
        - LIP-DELTA mode (MediaPipe): Tracks lip movement to detect who's talking
        - SIZE-BASED mode (fallback): Follows the largest face, which is usually
          the main subject / active speaker in professionally shot video

        For each frame:
        1. Match detected faces to existing tracked faces (spatial proximity)
        2. Compute lip-delta (or use size) for each matched face
        3. Select the best face as active speaker
        4. Apply hysteresis: don't switch speakers unless new one dominates for N frames
        """
        tracked_faces: list[_TrackedFace] = []
        next_face_id = 0
        current_speaker_id = -1
        speaker_switch_counter = 0

        keyframes: list[FaceKeyframe] = []
        person_keyframes: dict[int, list[FaceKeyframe]] = {}

        # Adjust match distance based on detection method
        # OpenCV Haar cascades produce jittery bounding boxes, need larger tolerance
        match_distance = 120 if has_lip_tracking else 200

        # Adjust hysteresis for size-based mode (less strict, since we
        # don't have lip-delta to confirm speech)
        size_mode_switch_threshold = 3  # frames (vs 8 for lip-delta mode)

        for ts, faces in frame_detections:
            if not faces:
                # No face detected — hold last known position
                if keyframes:
                    last = keyframes[-1]
                    keyframes.append(FaceKeyframe(
                        timestamp=ts,
                        center_x=last.center_x,
                        center_y=last.center_y,
                        width=last.width,
                        height=last.height,
                        confidence=0.0,
                        speaker_id=last.speaker_id,
                        lip_delta=0.0,
                    ))
                continue

            # ── Match faces to tracked identities ──
            matched_tracked = self._match_faces_to_tracks(
                faces, tracked_faces, ts, match_distance
            )

            # ── Create new tracks for unmatched faces ──
            matched_face_indices = {m[0] for m in matched_tracked}
            for fi, face in enumerate(faces):
                if fi not in matched_face_indices:
                    cx = face.x + face.w // 2
                    cy = face.y + face.h // 2
                    new_track = _TrackedFace(
                        face_id=next_face_id,
                        center_x=cx,
                        center_y=cy,
                        width=face.w,
                        height=face.h,
                        confidence=face.confidence,
                        prev_lip_landmarks=list(face.lip_landmarks),
                        lip_delta_history=[],
                        frames_seen=1,
                        last_seen_ts=ts,
                    )
                    tracked_faces.append(new_track)
                    matched_tracked.append((fi, new_track))
                    next_face_id += 1

            # ── Compute lip-deltas for matched faces ──
            for fi, track in matched_tracked:
                face = faces[fi]
                lip_delta = self._compute_lip_delta(
                    face.lip_landmarks, track.prev_lip_landmarks
                )

                # Update track state
                track.center_x = face.x + face.w // 2
                track.center_y = face.y + face.h // 2
                track.width = face.w
                track.height = face.h
                track.confidence = face.confidence
                track.prev_lip_landmarks = list(face.lip_landmarks)
                track.frames_seen += 1
                track.last_seen_ts = ts

                # Rolling window lip-delta
                track.lip_delta_history.append(lip_delta)
                if len(track.lip_delta_history) > self._LIP_DELTA_WINDOW:
                    track.lip_delta_history.pop(0)

            # ── Select active speaker ──
            if has_lip_tracking:
                best_speaker_track = self._select_speaker_lip_delta(matched_tracked)
            else:
                best_speaker_track = self._select_speaker_by_size(matched_tracked)

            if best_speaker_track is None:
                continue

            # ── Hysteresis: prevent flickering between speakers ──
            proposed_id = best_speaker_track.face_id
            switch_threshold = (
                self._SPEAKER_SWITCH_THRESHOLD if has_lip_tracking
                else size_mode_switch_threshold
            )

            if current_speaker_id == -1:
                # First speaker — lock immediately
                current_speaker_id = proposed_id
                speaker_switch_counter = 0
            elif proposed_id != current_speaker_id:
                # Different speaker proposed
                should_switch = False

                if has_lip_tracking:
                    # In lip-delta mode: require clear speech signal
                    avg_delta = (
                        sum(best_speaker_track.lip_delta_history)
                        / len(best_speaker_track.lip_delta_history)
                        if best_speaker_track.lip_delta_history else 0.0
                    )
                    should_switch = avg_delta > self._LIP_DELTA_SPEECH_THRESHOLD
                else:
                    # In size-based mode: switch if the proposed face is significantly
                    # larger (>30% more area) than the current speaker's face
                    current_track = None
                    for _, t in matched_tracked:
                        if t.face_id == current_speaker_id:
                            current_track = t
                            break

                    if current_track is None:
                        # Current speaker disappeared — allow switch immediately
                        should_switch = True
                    else:
                        proposed_area = best_speaker_track.width * best_speaker_track.height
                        current_area = current_track.width * current_track.height
                        # Switch if new face is > 30% larger
                        should_switch = proposed_area > current_area * 1.3

                if should_switch:
                    if proposed_id == candidate_speaker_id:
                        speaker_switch_counter += 1
                    else:
                        candidate_speaker_id = proposed_id
                        speaker_switch_counter = 1

                    if speaker_switch_counter >= switch_threshold:
                        # Confirmed speaker switch
                        logger.info(
                            f"[Speaker Tracker] SPEAKER SWITCH at {ts:.1f}s: "
                            f"person #{current_speaker_id} → person #{proposed_id} "
                            f"(held for {speaker_switch_counter} frames)"
                        )
                        current_speaker_id = proposed_id
                        speaker_switch_counter = 0
                        candidate_speaker_id = -1
                else:
                    # Not enough evidence for switch
                    speaker_switch_counter = 0
                    candidate_speaker_id = -1
            else:
                # Same speaker — reset counter
                speaker_switch_counter = 0
                candidate_speaker_id = -1

            # ── Find the track for the current speaker ──
            speaker_track: _TrackedFace | None = None
            for _, track in matched_tracked:
                if track.face_id == current_speaker_id:
                    speaker_track = track
                    break

            if speaker_track is None:
                # Current speaker disappeared — switch to best available
                speaker_track = best_speaker_track
                current_speaker_id = speaker_track.face_id
                logger.info(
                    f"[Speaker Tracker] Previous speaker lost at {ts:.1f}s, "
                    f"switching to person #{current_speaker_id} "
                    f"(size={speaker_track.width}x{speaker_track.height})"
                )

            avg_delta = (
                sum(speaker_track.lip_delta_history)
                / len(speaker_track.lip_delta_history)
                if speaker_track.lip_delta_history else 0.0
            )

            # Debug logging for multi-person frames (every 5th frame to reduce spam)
            frame_index = int((ts - frame_detections[0][0]) * self._SAMPLE_FPS)
            if len(faces) > 1 and frame_index % 5 == 0:
                all_scores = []
                for fi2, t2 in matched_tracked:
                    ad = (
                        sum(t2.lip_delta_history) / len(t2.lip_delta_history)
                        if t2.lip_delta_history else 0.0
                    )
                    all_scores.append(
                        f"person#{t2.face_id}:lip_delta={ad:.1f},size={t2.width}x{t2.height}"
                    )
                mode_str = "LIP-DELTA" if has_lip_tracking else "SIZE-BASED"
                logger.info(
                    f"[Speaker Tracker] [{mode_str}] Frame ts={ts:.1f}s: "
                    f"{len(faces)} people → active=person#{current_speaker_id} "
                    f"| scores: {', '.join(all_scores)}"
                )

            if faces:
                max_area = max(f.w * f.h for f in faces)
                # Only count faces that are at least 25% of the size of the largest face
                prominent_faces = sum(1 for f in faces if f.w * f.h >= max_area * 0.25)
            else:
                prominent_faces = 0

            keyframes.append(FaceKeyframe(
                timestamp=ts,
                center_x=speaker_track.center_x,
                center_y=speaker_track.center_y,
                width=speaker_track.width,
                height=speaker_track.height,
                confidence=speaker_track.confidence,
                speaker_id=current_speaker_id,
                lip_delta=avg_delta,
                num_faces=prominent_faces,
            ))

            for _, track in matched_tracked:
                if track.face_id not in person_keyframes:
                    person_keyframes[track.face_id] = []
                person_keyframes[track.face_id].append(FaceKeyframe(
                    timestamp=ts,
                    center_x=track.center_x,
                    center_y=track.center_y,
                    width=track.width,
                    height=track.height,
                    confidence=track.confidence,
                    speaker_id=track.face_id,
                    num_faces=prominent_faces,
                ))

            # ── Prune stale tracks (not seen for > 2 seconds) ──
            tracked_faces = [
                t for t in tracked_faces if (ts - t.last_seen_ts) < 2.0
            ]

        return keyframes, person_keyframes

    # ─────────────────────────────────────────────────────────────
    #  Speaker selection strategies
    # ─────────────────────────────────────────────────────────────

    def _select_speaker_lip_delta(
        self, matched_tracked: list[tuple[int, _TrackedFace]]
    ) -> _TrackedFace | None:
        """Select speaker by lip-delta (MediaPipe mode).

        Picks the face with the highest rolling average lip movement,
        with a small size bonus for closer faces.
        """
        best_track: _TrackedFace | None = None
        best_score = -1.0

        for fi, track in matched_tracked:
            if not track.lip_delta_history:
                continue
            avg_delta = sum(track.lip_delta_history) / len(track.lip_delta_history)

            # Bonus: larger faces get a small boost (closer = more important)
            size_bonus = (track.width * track.height) ** 0.3 * 0.01
            score = avg_delta + size_bonus

            if score > best_score:
                best_score = score
                best_track = track

        if best_track is None:
            # No lip-delta data yet — pick largest face
            return self._select_speaker_by_size(matched_tracked)

        return best_track

    def _select_speaker_by_size(
        self, matched_tracked: list[tuple[int, _TrackedFace]]
    ) -> _TrackedFace | None:
        """Select speaker by face size (fallback mode).

        In professionally shot video, the main subject / active speaker
        is typically the largest face on screen. This provides a robust
        fallback when lip-delta tracking is unavailable.
        """
        best_track: _TrackedFace | None = None
        best_area = -1

        for fi, track in matched_tracked:
            area = track.width * track.height

            # Bonus for faces that have been tracked longer (more stable)
            stability_bonus = min(track.frames_seen, 10) * 100
            score = area + stability_bonus

            if score > best_area:
                best_area = score
                best_track = track

        return best_track

    # ─────────────────────────────────────────────────────────────
    #  Face matching
    # ─────────────────────────────────────────────────────────────

    def _match_faces_to_tracks(
        self,
        faces: list[FaceRegion],
        tracked: list[_TrackedFace],
        ts: float,
        match_distance: int = 120,
    ) -> list[tuple[int, _TrackedFace]]:
        """Match detected faces to existing tracked identities by spatial proximity.

        Returns list of (face_index, tracked_face) pairs.
        Uses size-aware matching: distance is scaled by face size ratio to
        handle OpenCV's jittery bounding boxes better.
        """
        if not tracked:
            return []

        matches: list[tuple[int, _TrackedFace]] = []
        used_tracks: set[int] = set()
        used_faces: set[int] = set()

        # Greedy nearest-neighbor matching with size-aware distance
        pairs: list[tuple[float, int, int]] = []
        for fi, face in enumerate(faces):
            fcx = face.x + face.w // 2
            fcy = face.y + face.h // 2
            face_size = max(face.w, face.h)
            for ti, track in enumerate(tracked):
                dist = ((fcx - track.center_x) ** 2 + (fcy - track.center_y) ** 2) ** 0.5

                # Scale match distance by average face size (larger faces can move more)
                track_size = max(track.width, track.height)
                avg_size = (face_size + track_size) / 2
                # Also consider size similarity — faces should be roughly the same size
                size_ratio = max(face_size, track_size) / max(min(face_size, track_size), 1)

                # Allow larger distance for larger faces, but penalize if size changed too much
                effective_distance = match_distance + avg_size * 0.3
                if size_ratio > 3.0:
                    # Size is too different — probably not the same face
                    continue

                if dist < effective_distance:
                    # Combined distance score: spatial + size difference penalty
                    score = dist + (size_ratio - 1.0) * 30
                    pairs.append((score, fi, ti))

        # Sort by distance and greedily assign
        pairs.sort()
        for score, fi, ti in pairs:
            if fi in used_faces or ti in used_tracks:
                continue
            matches.append((fi, tracked[ti]))
            used_faces.add(fi)
            used_tracks.add(ti)

        return matches

    @staticmethod
    def _compute_lip_delta(
        current_landmarks: list[float],
        prev_landmarks: list[float],
    ) -> float:
        """Compute how much lip landmarks moved between two frames.

        Returns sum of absolute pixel displacements across all tracked
        lip landmarks. High value = lips are moving = person is speaking.
        Zero/low value = lips are still = person is listening.
        """
        if not current_landmarks or not prev_landmarks:
            return 0.0
        if len(current_landmarks) != len(prev_landmarks):
            return 0.0

        total_delta = 0.0
        for i in range(len(current_landmarks)):
            total_delta += abs(current_landmarks[i] - prev_landmarks[i])

        return total_delta

    # ─────────────────────────────────────────────────────────────
    #  Phase 4: Collapse to step-function keyframes
    # ─────────────────────────────────────────────────────────────

    def _collapse_to_steps(
        self,
        keyframes: list[FaceKeyframe],
        video_width: int = 1920,
        video_height: int = 1080,
    ) -> list[FaceKeyframe]:
        """Process camera trajectory with Deadzone, Smooth Panning, and Hard Jump Cuts.

        - 12% Deadzone (~230px in 1080p width): If the same speaker moves slightly (e.g. tilting head, nodding, shifting posture), the camera stays 100% locked. Zero jitter.
        - Smooth Panning (is_hard_cut = False): If the same speaker moves significantly across the frame, emits a keyframe marked for smooth linear interpolation (pan).
        - Hard Jump Cut (is_hard_cut = True): When switching to a different speaker, instantly teleports the crop window (snappy cinema-grade cut).
        """
        if not keyframes:
            return []

        collapsed: list[FaceKeyframe] = [keyframes[0]]
        collapsed[0].is_hard_cut = True

        # 12% deadzone of video dimensions (~230px in 1080p width, ~129px in 1080p height)
        # Prevents jittery jump cuts when a person tilts their head or moves slightly in their chair.
        deadzone_x = max(60, int(video_width * 0.12)) if video_width > 0 else 130
        deadzone_y = max(60, int(video_height * 0.12)) if video_height > 0 else 130

        for kf in keyframes[1:]:
            prev = collapsed[-1]
            dx = abs(kf.center_x - prev.center_x)
            dy = abs(kf.center_y - prev.center_y)
            is_speaker_switch = (kf.speaker_id != prev.speaker_id and kf.speaker_id != -1 and prev.speaker_id != -1)

            if is_speaker_switch:
                # Speaker switch -> Always emit a clean HARD JUMP CUT to the new speaker
                kf.is_hard_cut = True
                collapsed.append(kf)
            elif dx > deadzone_x or dy > deadzone_y:
                # Same speaker moved significantly outside the deadzone -> Emit a SMOOTH PAN
                kf.is_hard_cut = False
                collapsed.append(kf)
            # Else: Movement is within deadzone (head tilt / minor posture shift) -> IGNORE (holds camera rock-solid!)

        logger.info(
            f"[Speaker Tracker] Processed {len(keyframes)} raw keyframes "
            f"→ {len(collapsed)} hybrid camera positions (deadzone={deadzone_x}x{deadzone_y}px)"
        )

        return collapsed

    # ─────────────────────────────────────────────────────────────
    #  Frame extraction
    # ─────────────────────────────────────────────────────────────

    def _extract_frames_ffmpeg(
        self,
        video_path: Path,
        start_time: float,
        end_time: float,
        sample_fps: float,
        expected_count: int,
    ) -> list["np.ndarray"]:
        """Extract frames using FFmpeg with GPU hardware acceleration."""
        import cv2  # type: ignore
        import numpy as np

        with tempfile.TemporaryDirectory() as tmpdir:
            out_pattern = f"{tmpdir}/frame_%06d.jpg"
            duration = end_time - start_time

            # Try GPU-accelerated extraction first
            for attempt, cmd in enumerate([
                # Attempt 1: NVDEC hardware acceleration
                [
                    "ffmpeg", "-y",
                    "-hwaccel", "cuda", "-hwaccel_output_format", "cuda",
                    "-ss", str(start_time),
                    "-i", str(video_path),
                    "-t", str(duration),
                    "-vf", f"hwdownload,format=nv12,fps={sample_fps}",
                    "-q:v", "2",
                    "-vsync", "vfr",
                    out_pattern,
                ],
                # Attempt 2: CPU-only extraction
                [
                    "ffmpeg", "-y",
                    "-ss", str(start_time),
                    "-i", str(video_path),
                    "-t", str(duration),
                    "-vf", f"fps={sample_fps}",
                    "-q:v", "2",
                    "-vsync", "vfr",
                    out_pattern,
                ],
            ]):
                try:
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        timeout=120,
                    )
                    if result.returncode == 0:
                        if attempt == 0:
                            logger.debug("[Speaker Tracker] GPU frame extraction succeeded")
                        else:
                            logger.debug("[Speaker Tracker] CPU frame extraction succeeded")
                        break
                except (subprocess.TimeoutExpired, FileNotFoundError):
                    continue
            else:
                logger.error("[Speaker Tracker] FFmpeg frame extraction failed entirely")
                return []

            # Read extracted frames
            frames: list[np.ndarray] = []
            frame_files = sorted(Path(tmpdir).glob("frame_*.jpg"))
            for fp in frame_files:
                img = cv2.imread(str(fp))
                if img is not None:
                    frames.append(img)

        return frames

    # ── Legacy API (kept for backward compatibility) ──

    async def get_dominant_face_region(
        self,
        video_path: Path,
        start_time: float,
        end_time: float,
        sample_interval: float = 1.0,
    ) -> FaceRegion | None:
        """Sample frames from video clip and find the dominant face position.

        Legacy method — prefer build_face_timeline() for dynamic tracking.
        """
        timelines = await self.build_face_timeline(
            video_path, start_time, end_time, sample_fps=1.0 / sample_interval
        )
        timeline = timelines[0]
        if not timeline.keyframes:
            return None

        import numpy as np
        med_cx = int(np.median([kf.center_x for kf in timeline.keyframes]))
        med_cy = int(np.median([kf.center_y for kf in timeline.keyframes]))
        med_w = int(
            np.median([kf.width for kf in timeline.keyframes if kf.width > 0])
            or 100
        )
        med_h = int(
            np.median([kf.height for kf in timeline.keyframes if kf.height > 0])
            or 100
        )

        return FaceRegion(
            x=med_cx - med_w // 2,
            y=med_cy - med_h // 2,
            w=med_w,
            h=med_h,
            confidence=1.0,
        )
