import asyncio
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class AudioMixer:
    """Mixes background music (BGM) and sound effects (SFX) into a video."""
    
    def __init__(self, assets_dir: Path):
        self.assets_dir = assets_dir
        
    async def mix_audio(
        self,
        input_video: Path,
        output_video: Path,
        mood: str | None = None,
        sfx_timestamps: list[float] | None = None,
    ) -> Path:
        """Mix BGM and SFX into the video using FFmpeg."""
        mood = mood or "chill"
        bgm_path = self.assets_dir / "bgm" / f"{mood}.mp3"
        sfx_path = self.assets_dir / "sfx" / "whoosh.mp3"
        
        has_bgm = bgm_path.exists()
        sfx_times = sfx_timestamps if sfx_timestamps else []
        has_sfx = sfx_path.exists() and len(sfx_times) > 0
        
        if not has_bgm and not has_sfx:
            logger.info("[AudioMixer] No audio assets found, skipping mixing.")
            import shutil
            shutil.copy2(input_video, output_video)
            return output_video
            
        cmd = ["ffmpeg", "-y", "-i", str(input_video)]
        filter_complex = []
        audio_inputs = 1
        
        if has_bgm:
            cmd.extend(["-stream_loop", "-1", "-i", str(bgm_path)])
            # Duck BGM volume to 8%
            filter_complex.append(f"[{audio_inputs}:a]volume=0.08[bgm]")
            audio_inputs += 1
            
        sfx_outputs = []
        if has_sfx:
            for ts in sfx_times:
                cmd.extend(["-i", str(sfx_path)])
                delay_ms = int(ts * 1000)
                sfx_out = f"sfx_{audio_inputs}"
                filter_complex.append(f"[{audio_inputs}:a]adelay={delay_ms}|{delay_ms},volume=0.5[{sfx_out}]")
                sfx_outputs.append(f"[{sfx_out}]")
                audio_inputs += 1
            
        # Mix everything together
        mix_inputs = "[0:a]"
        if has_bgm:
            mix_inputs += "[bgm]"
        if has_sfx:
            mix_inputs += "".join(sfx_outputs)
            
        filter_complex.append(f"{mix_inputs}amix=inputs={audio_inputs}:duration=first:dropout_transition=2[aout]")
        
        cmd.extend([
            "-filter_complex", ";".join(filter_complex),
            "-map", "0:v",
            "-map", "[aout]",
            "-c:v", "copy",
            "-c:a", "aac",
            str(output_video)
        ])
        
        logger.info(f"[AudioMixer] Mixing audio for {input_video.name} with mood={mood}")
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await process.communicate()
        
        if process.returncode != 0:
            logger.warning(f"[AudioMixer] FFmpeg failed: {stderr.decode()[-300:]}")
            import shutil
            shutil.copy2(input_video, output_video)
            
        return output_video
