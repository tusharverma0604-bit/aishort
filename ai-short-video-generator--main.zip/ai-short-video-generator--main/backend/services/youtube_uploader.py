import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

from backend.config import Settings
from backend.models.project import ProcessedClip, Project

logger = logging.getLogger(__name__)


class YouTubeUploader:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.creds_path = settings.storage_dir / "youtube_credentials.json"

    def _get_credentials(self) -> Credentials | None:
        if not self.creds_path.exists():
            return None
            
        with open(self.creds_path, 'r') as f:
            creds_data = json.load(f)
            
        return Credentials(
            token=creds_data['token'],
            refresh_token=creds_data['refresh_token'],
            token_uri=creds_data['token_uri'],
            client_id=creds_data['client_id'],
            client_secret=creds_data['client_secret'],
            scopes=creds_data['scopes']
        )

    async def upload_clip(self, project: Project, clip: ProcessedClip, clip_index: int) -> str | None:
        """Uploads a clip to YouTube based on the project's youtube_upload_mode."""
        mode = project.settings.youtube_upload_mode
        if mode == "off":
            return None
            
        credentials = self._get_credentials()
        if not credentials:
            logger.warning("YouTube auto-upload skipped: No credentials found.")
            return None

        youtube = build("youtube", "v3", credentials=credentials)
        
        # Determine the video file to upload
        video_path = clip.final_path or clip.captioned_path or clip.reframed_path
        if not video_path or not Path(video_path).exists():
            raise ValueError(f"No valid video file found for clip {clip.clip_id}")

        # Construct metadata
        title = clip.candidate.youtube_title or f"{clip.candidate.title} #shorts"
        description = clip.candidate.youtube_description or clip.candidate.reason
        tags = clip.candidate.tags or ["shorts"]

        # Ensure title is <= 100 chars
        if len(title) > 100:
            title = title[:97] + "..."

        privacy_status = "private"
        publish_at = None

        if mode == "public":
            privacy_status = "public"
        elif mode == "private":
            privacy_status = "private"
        elif mode == "schedule":
            privacy_status = "private"
            
            start_time_str = project.settings.youtube_schedule_start_time
            interval_hours = project.settings.youtube_schedule_interval_hours or 24
            
            if start_time_str:
                try:
                    # Parse the ISO string (e.g. 2026-08-01T12:00:00Z)
                    start_date = datetime.fromisoformat(start_time_str.replace('Z', '+00:00'))
                except ValueError:
                    start_date = datetime.now(timezone.utc) + timedelta(days=1)
            else:
                # Default fallback: tomorrow 12:00 PM UTC
                start_date = datetime.now(timezone.utc) + timedelta(days=1)
                start_date = start_date.replace(hour=12, minute=0, second=0, microsecond=0)
                
            # Ensure it has timezone info
            if start_date.tzinfo is None:
                start_date = start_date.replace(tzinfo=timezone.utc)
                
            scheduled_date = start_date + timedelta(hours=(clip_index * interval_hours))
            publish_at = scheduled_date.isoformat()

        body = {
            "snippet": {
                "title": title,
                "description": description,
                "tags": tags,
                "categoryId": "22", # People & Blogs default
            },
            "status": {
                "privacyStatus": privacy_status,
                "selfDeclaredMadeForKids": False,
            }
        }
        
        if publish_at:
            body["status"]["publishAt"] = publish_at

        logger.info(f"Uploading {clip.clip_id} to YouTube. Mode: {mode}, Title: {title}")

        media = MediaFileUpload(
            video_path,
            mimetype="video/mp4",
            resumable=True
        )

        # Build the request and execute it in a thread pool (since it's a blocking network call)
        import asyncio
        loop = asyncio.get_running_loop()
        
        def _execute_upload():
            request = youtube.videos().insert(
                part="snippet,status",
                body=body,
                media_body=media
            )
            return request.execute()
            
        response = await loop.run_in_executor(None, _execute_upload)
        
        video_id = response.get("id")
        logger.info(f"Successfully uploaded {clip.clip_id} to YouTube. Video ID: {video_id}")
        return video_id
