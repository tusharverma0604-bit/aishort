import json
import logging
from typing import Any, List
from openai import AsyncOpenAI

from backend.services.llm.providers.base import LLMProvider

logger = logging.getLogger(__name__)

class CustomProvider(LLMProvider):
    """
    Universal LLM provider using the standard OpenAI client.
    Works with OpenAI, Groq, DeepSeek, OpenRouter, TogetherAI, LocalAI, etc.
    """

    def __init__(self, api_keys: List[str], base_url: str, model: str):
        if not api_keys or not api_keys[0]:
            raise ValueError("No API keys provided for CustomProvider.")
        
        # Filter out empty keys
        self.api_keys = [k.strip() for k in api_keys if k.strip()]
        if not self.api_keys:
            raise ValueError("All provided API keys were empty.")
            
        self.base_url = base_url.strip()
        self.model = model.strip()
        self.current_key_index = 0
        
        self.client = AsyncOpenAI(
            api_key=self.api_keys[self.current_key_index],
            base_url=self.base_url
        )

    def _rotate_key(self) -> bool:
        """Rotates to the next API key. Returns True if rotated, False if exhausted."""
        if self.current_key_index >= len(self.api_keys) - 1:
            return False  # No more keys to try
            
        self.current_key_index += 1
        logger.warning(f"Rotating to API key index {self.current_key_index} for custom provider.")
        
        # Re-initialize client with the new key
        self.client = AsyncOpenAI(
            api_key=self.api_keys[self.current_key_index],
            base_url=self.base_url
        )
        return True

    async def chat_completion(
        self, 
        messages: list[dict[str, Any]], 
        temperature: float = 0.7, 
        max_tokens: int = 4096, 
        response_schema: Any = None
    ) -> str:
        """Send a chat completion request and return the response text, with automatic fallback."""
        
        # Convert schema to JSON schema if provided
        kwargs = {}
        if response_schema:
            try:
                # If it's a Pydantic model
                schema_json = response_schema.model_json_schema()
                kwargs['response_format'] = {
                    "type": "json_schema", 
                    "json_schema": {
                        "name": "response_schema",
                        "schema": schema_json,
                        "strict": True
                    }
                }
            except Exception as e:
                # Fallback to standard json mode if the provider doesn't support strict schema
                logger.warning(f"Could not convert schema or provider doesn't support structured outputs: {e}")
                kwargs['response_format'] = {"type": "json_object"}

        while True:
            try:
                response = await self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    **kwargs
                )
                
                return response.choices[0].message.content
                
            except Exception as e:
                error_msg = str(e).lower()
                logger.error(f"OpenAI Client Error: {e}")
                
                # Check for rate limit or authentication errors
                if "429" in error_msg or "rate limit" in error_msg or "401" in error_msg or "403" in error_msg or "unauthorized" in error_msg:
                    if self._rotate_key():
                        logger.info("Retrying with new API key...")
                        continue
                    else:
                        logger.error("All custom API keys exhausted.")
                        raise ValueError(f"All API keys exhausted. Last error: {e}")
                else:
                    # Reraise other errors (like invalid request, etc)
                    raise

    async def list_models(self) -> list[str]:
        """List available models."""
        try:
            models = await self.client.models.list()
            return [model.id for model in models.data]
        except Exception:
            return [self.model]

    async def get_model_name(self) -> str:
        return self.model
