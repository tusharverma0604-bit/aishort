from typing import List
from backend.services.llm.providers.base import LLMProvider
from backend.services.llm.providers.gemini import GeminiProvider
from backend.services.llm.providers.custom import CustomProvider

def create_llm_provider(provider: str, base_url: str, api_keys: List[str], model: str) -> LLMProvider:
    if provider == 'gemini':
        return GeminiProvider(api_keys, model)
    elif provider == 'custom':
        return CustomProvider(api_keys, base_url, model)
    raise ValueError(f'Unknown provider: {provider}')
