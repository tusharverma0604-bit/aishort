from abc import ABC, abstractmethod
from typing import Any

class LLMProvider(ABC):
    """Abstract base class for LLM providers."""
    
    @abstractmethod
    async def chat_completion(
        self, messages: list[dict[str, Any]], temperature: float = 0.7, max_tokens: int = 4096, response_schema: Any = None
    ) -> str:
        """Send a chat completion request and return the response text."""
    
    @abstractmethod
    async def list_models(self) -> list[str]:
        """List available models."""
    
    @abstractmethod
    async def get_model_name(self) -> str:
        """Get the name of the currently active model."""
