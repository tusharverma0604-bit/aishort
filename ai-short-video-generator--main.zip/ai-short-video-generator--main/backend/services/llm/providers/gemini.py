import json
import logging
from typing import Any

from google import genai
from google.genai import types

from backend.services.llm.providers.base import LLMProvider

logger = logging.getLogger(__name__)

class GeminiProvider(LLMProvider):
    def __init__(self, api_keys: list[str] | str, model: str = "gemini-1.5-flash"):
        if isinstance(api_keys, str):
            self.api_keys = [api_keys] if api_keys else []
        else:
            self.api_keys = [k for k in api_keys if k]
            
        self.model = "gemini-1.5-flash" if model == "auto" else model
        self.current_key_index = 0
        
        if not self.api_keys:
            logger.warning("No Gemini API keys provided. LLM calls will fail.")
            self.client = None
        else:
            self._init_client()

    def _init_client(self):
        """Initialize the client with the current active API key."""
        if not self.api_keys:
            return
            
        current_key = self.api_keys[self.current_key_index]
        self.client = genai.Client(api_key=current_key)
        
        try:
            # Check available models to prevent 404 errors
            available = []
            for m in self.client.models.list():
                if m.name and m.supported_actions and "generateContent" in m.supported_actions:
                    available.append(m.name.replace("models/", ""))
            
            if self.model not in available:
                logger.warning(f"Model {self.model} not available. Finding fallback...")
                safe_models = [m for m in available if "flash" in m and "tts" not in m and "image" not in m and "preview" not in m and "lite" not in m]
                priorities = ["gemini-3.5-flash", "gemini-3.6-flash", "gemini-flash-latest"]
                chosen_model = next((p for p in priorities if p in safe_models or p in available), "")
                
                if not chosen_model and safe_models:
                    chosen_model = safe_models[0]
                elif not chosen_model and available:
                    chosen_model = available[0]
                            
                if chosen_model:
                    self.model = chosen_model
                    logger.info(f"Fallback to {self.model}")
        except Exception as e:
            logger.error(f"Failed to query available models during init: {e}")

    def _rotate_key(self) -> bool:
        """Switch to the next API key. Returns True if a new key was selected, False if exhausted."""
        if not self.api_keys or len(self.api_keys) <= 1:
            return False
            
        self.current_key_index += 1
        if self.current_key_index >= len(self.api_keys):
            self.current_key_index = 0
            return False # We looped all the way around
            
        logger.info(f"Rotating to API key #{self.current_key_index + 1} of {len(self.api_keys)}")
        self._init_client()
        return True

    async def chat_completion(
        self, messages: list[dict[str, Any]], temperature: float = 0.7, max_tokens: int = 4096, response_schema: Any = None
    ) -> str:
        if not self.api_keys:
            raise ValueError("No Gemini API keys configured. Please add one in Settings.")

        prompt = ""
        for msg in messages:
            prompt += f"{msg['role'].upper()}:\n{msg['content']}\n\n"

        kwargs = {
            "response_mime_type": "application/json",
            "temperature": temperature,
            "max_output_tokens": max_tokens,
            "safety_settings": [
                types.SafetySetting(category="HARM_CATEGORY_HATE_SPEECH", threshold="BLOCK_NONE"),
                types.SafetySetting(category="HARM_CATEGORY_HARASSMENT", threshold="BLOCK_NONE"),
                types.SafetySetting(category="HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold="BLOCK_NONE"),
                types.SafetySetting(category="HARM_CATEGORY_DANGEROUS_CONTENT", threshold="BLOCK_NONE"),
            ]
        }
        if response_schema is not None:
            kwargs["response_schema"] = response_schema
            
        # Retry loop for fallback logic
        attempts = 0
        max_attempts = len(self.api_keys)
        
        while attempts < max_attempts:
            try:
                logger.info(f"Calling Gemini API (model {self.model}, key #{self.current_key_index + 1})...")
                response = self.client.models.generate_content(
                    model=self.model,
                    contents=prompt,
                    config=types.GenerateContentConfig(**kwargs),
                )
                
                if not response.text:
                    raise ValueError("Empty response from Gemini")

                text = response.text.strip()
                if text.startswith("```json"): text = text[7:]
                if text.endswith("```"): text = text[:-3]
                    
                return text.strip()
                
            except Exception as e:
                error_str = str(e).lower()
                # 429 Too Many Requests, or 401 Unauthorized/403 Forbidden
                if "429" in error_str or "quota" in error_str or "401" in error_str or "403" in error_str:
                    logger.warning(f"API key #{self.current_key_index + 1} failed ({e}). Attempting rotation...")
                    if self._rotate_key():
                        attempts += 1
                        continue
                    else:
                        logger.error("All API keys exhausted.")
                        raise ValueError("All configured API keys failed (Rate limited or invalid).")
                else:
                    # For non-auth/quota errors, raise immediately
                    logger.error(f"Error calling Gemini: {e}")
                    raise

    async def get_model_name(self) -> str:
        return self.model
        
    async def list_models(self) -> list[str]:
        return ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-1.5-pro", "gemini-1.5-flash"]
