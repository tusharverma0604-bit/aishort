import json
import logging
import re
from pathlib import Path

from backend.models.project import Transcript, ViralClipCandidate, ViralClipResponse
from backend.exceptions import LLMError
from backend.services.llm.providers.base import LLMProvider

logger = logging.getLogger(__name__)

class ViralAnalyzer:
    """Analyzes transcripts to find viral-worthy moments."""
    
    def __init__(self, llm_provider: LLMProvider, prompts_dir: Path):
        self.llm = llm_provider
        self.prompts_dir = prompts_dir
        self.prompt_path = self.prompts_dir / "viral_moments.txt"
    
    async def analyze(
        self,
        transcript: Transcript,
        min_score: int = 75,
        max_clips: int = 10,
        min_duration: int = 15,
        max_duration: int = 60,
    ) -> list[ViralClipCandidate]:
        """Find viral moments in transcript."""
        if not self.prompt_path.exists():
            raise FileNotFoundError(f"Prompt file not found at {self.prompt_path}")
            
        with open(self.prompt_path, "r", encoding="utf-8") as f:
            prompt_template = f.read()
            
        # Build timestamped transcript for the LLM so it can identify start/end times
        transcript_text = transcript.full_text
        if not transcript_text and transcript.segments:
            transcript_text = " ".join(s.text for s in transcript.segments)

        # Also build a timestamped version for more accurate time references
        timestamped_lines = []
        for seg in transcript.segments:
            timestamped_lines.append(f"[{seg.start:.1f}s - {seg.end:.1f}s] {seg.text.strip()}")
        if timestamped_lines:
            transcript_text = "\n".join(timestamped_lines)
            
        prompt = prompt_template.replace("{transcript}", transcript_text).replace("{max_clips}", str(max_clips))
        
        messages = [
            {"role": "system", "content": "You are a helpful assistant that strictly outputs JSON."},
            {"role": "user", "content": prompt}
        ]
        
        import asyncio
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = await self.llm.chat_completion(
                    messages=messages, 
                    temperature=0.7, 
                    max_tokens=8192
                )
                clips = self._parse_llm_response(response)
                break
            except Exception as e:
                logger.error(f"Failed to analyze transcript (attempt {attempt+1}/{max_retries}): {e}")
                if "429" in str(e) or "RESOURCE_EXHAUSTED" in str(e) or "exceeded" in str(e).lower():
                    if attempt < max_retries - 1:
                        logger.warning("Rate limit hit. Sleeping for 45s before retry...")
                        await asyncio.sleep(45)
                        continue
                if attempt == max_retries - 1:
                    raise LLMError(f"Transcript analysis failed: {e}") from e
            
        # Filter by score and duration
        valid_clips = []
        for clip in clips:
            duration = clip.end_time - clip.start_time
            if clip.score >= min_score and min_duration <= duration <= max_duration:
                valid_clips.append(clip)
                
        # Merge overlapping clips
        merged_clips = self._merge_overlapping(valid_clips)
        
        # Sort by score descending and return top max_clips
        merged_clips.sort(key=lambda x: x.score, reverse=True)
        return merged_clips[:max_clips]
    
    def _merge_overlapping(self, clips: list[ViralClipCandidate], threshold: float = 5.0) -> list[ViralClipCandidate]:
        """
        Merge clips that overlap within threshold seconds.
        Keep the higher-scored clip when merging.
        """
        if not clips:
            return []
            
        sorted_by_time = sorted(clips, key=lambda x: x.start_time)
        merged = []
        
        for current_clip in sorted_by_time:
            if not merged:
                merged.append(current_clip)
                continue
                
            last_clip = merged[-1]
            
            # They overlap if current starts before last ends + threshold
            if current_clip.start_time <= (last_clip.end_time + threshold):
                if current_clip.score > last_clip.score:
                    merged[-1] = current_clip
            else:
                merged.append(current_clip)
                
        return merged
    
    def _parse_llm_response(self, response: str) -> list[ViralClipCandidate]:
        """
        Parse LLM JSON response into ViralClipCandidate list.
        Handle markdown code blocks, invalid JSON gracefully.
        """
        # Pre-process: escape unescaped newlines inside the raw string if possible,
        # but the easiest way is to just let json.loads try first.
        try:
            # Clean control characters that might break JSON parsing
            cleaned_response = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', response)
            return self._parse_json_list(cleaned_response)
        except (json.JSONDecodeError, ValueError):
            # Extract JSON from markdown fences
            match = re.search(r'```(?:json)?\s*(.*?)\s*```', response, re.DOTALL)
            if match:
                try:
                    return self._parse_json_list(match.group(1))
                except (json.JSONDecodeError, ValueError):
                    pass
            
            # Fallback to finding object brackets since we expect {"clips": [...]}
            start_idx = response.find('{')
            if start_idx != -1:
                json_str = response[start_idx:]
                # Try to fix truncated object if it doesn't end with }
                if not json_str.strip().endswith('}'):
                    last_brace = json_str.rfind('}')
                    if last_brace != -1:
                        json_str = json_str[:last_brace+1]
                    else:
                        json_str += '}'
                
                try:
                    return self._parse_json_list(json_str)
                except (json.JSONDecodeError, ValueError) as e:
                    logger.warning(f"Failed to parse cleaned JSON: {e}")
                    logger.error(f"RAW JSON STRING THAT FAILED (Length: {len(json_str)}):\n{json_str}")
                    
            raise ValueError("Failed to parse valid JSON array from LLM response.")

    def _parse_json_list(self, json_str: str) -> list[ViralClipCandidate]:
        data = json.loads(json_str)
        if isinstance(data, dict) and "clips" in data:
            data = data["clips"]
        if not isinstance(data, list):
            raise ValueError("Expected a JSON array or an object with a 'clips' array")
        
        return [ViralClipCandidate(**item) for item in data]
