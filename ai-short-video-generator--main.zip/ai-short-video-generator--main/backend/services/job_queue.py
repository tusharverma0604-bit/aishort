"""Async job queue for background pipeline processing."""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, AsyncGenerator, Callable, Coroutine

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class JobStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Job(BaseModel):
    id: str
    project_id: str
    status: JobStatus = JobStatus.QUEUED
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error: str | None = None


class JobQueue:
    """Async job queue using asyncio tasks.

    Features:
    - Background processing with configurable concurrency
    - SSE event streaming per project
    - Job cancellation and status tracking
    - Graceful shutdown
    """

    def __init__(self, max_concurrent: int = 1) -> None:
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._active_jobs: dict[str, Job] = {}
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._event_subscribers: dict[str, list[asyncio.Queue[dict[str, Any]]]] = {}
        self._started = False

    async def start(self) -> None:
        """Mark the queue as started. Call from within an event loop."""
        self._started = True
        logger.info("Job queue started (max_concurrent=%d)", self._semaphore._value)

    async def submit(
        self,
        project_id: str,
        pipeline_fn: Callable[[str], Coroutine[Any, Any, None]],
    ) -> Job:
        """Submit a pipeline function for background execution.

        Args:
            project_id: The project this job belongs to.
            pipeline_fn: An async callable that takes (project_id) as its argument.
        """
        job = Job(id=str(uuid.uuid4()), project_id=project_id)
        self._active_jobs[job.id] = job

        task = asyncio.create_task(
            self._run_with_semaphore(job, pipeline_fn),
            name=f"job-{job.id[:8]}",
        )
        self._tasks[job.id] = task

        await self.publish_event(project_id, {
            "type": "job_queued",
            "job_id": job.id,
            "status": JobStatus.QUEUED.value,
            "message": "Job queued for processing",
        })

        logger.info("Job %s submitted for project %s", job.id[:8], project_id[:8])
        return job

    async def cancel(self, job_id: str) -> bool:
        """Cancel a running or queued job."""
        job = self._active_jobs.get(job_id)
        if not job:
            return False

        if job.status in (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED):
            return False

        task = self._tasks.get(job_id)
        if task and not task.done():
            task.cancel()

        job.status = JobStatus.CANCELLED
        job.completed_at = datetime.now(timezone.utc)

        await self.publish_event(job.project_id, {
            "type": "job_cancelled",
            "job_id": job.id,
            "status": JobStatus.CANCELLED.value,
            "message": "Job cancelled",
        })

        logger.info("Job %s cancelled", job.id[:8])
        return True

    async def cancel_by_project(self, project_id: str) -> bool:
        """Cancel the active job for a project."""
        job = self.get_job_by_project(project_id)
        if job and job.status in (JobStatus.QUEUED, JobStatus.RUNNING):
            return await self.cancel(job.id)
        return False

    def get_job(self, job_id: str) -> Job | None:
        return self._active_jobs.get(job_id)

    def get_job_by_project(self, project_id: str) -> Job | None:
        """Get the most recent active job for a project."""
        active = [
            j for j in self._active_jobs.values()
            if j.project_id == project_id
            and j.status in (JobStatus.QUEUED, JobStatus.RUNNING)
        ]
        if active:
            return max(active, key=lambda j: j.created_at)

        all_jobs = [
            j for j in self._active_jobs.values()
            if j.project_id == project_id
        ]
        if all_jobs:
            return max(all_jobs, key=lambda j: j.created_at)
        return None

    async def subscribe(self, project_id: str) -> AsyncGenerator[dict[str, Any], None]:
        """Subscribe to SSE events for a project.

        Yields event dicts until the subscriber disconnects.
        """
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()

        if project_id not in self._event_subscribers:
            self._event_subscribers[project_id] = []
        self._event_subscribers[project_id].append(queue)

        try:
            while True:
                event = await queue.get()
                yield event
        except asyncio.CancelledError:
            pass
        finally:
            if project_id in self._event_subscribers:
                subs = self._event_subscribers[project_id]
                if queue in subs:
                    subs.remove(queue)
                if not subs:
                    del self._event_subscribers[project_id]

    async def publish_event(self, project_id: str, event: dict[str, Any]) -> None:
        """Publish an event to all subscribers of a project."""
        subscribers = self._event_subscribers.get(project_id, [])
        for queue in subscribers:
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning("Event queue full for project %s, dropping event", project_id[:8])

    async def _run_with_semaphore(
        self,
        job: Job,
        pipeline_fn: Callable[[str], Coroutine[Any, Any, None]],
    ) -> None:
        """Acquire semaphore, then process the job."""
        async with self._semaphore:
            await self._process_job(job, pipeline_fn)

    async def _process_job(
        self,
        job: Job,
        pipeline_fn: Callable[[str], Coroutine[Any, Any, None]],
    ) -> None:
        """Execute the pipeline function and handle lifecycle."""
        job.status = JobStatus.RUNNING
        job.started_at = datetime.now(timezone.utc)

        await self.publish_event(job.project_id, {
            "type": "job_started",
            "job_id": job.id,
            "status": JobStatus.RUNNING.value,
            "message": "Processing started",
        })

        try:
            await pipeline_fn(job.project_id)

            job.status = JobStatus.COMPLETED
            await self.publish_event(job.project_id, {
                "type": "job_completed",
                "job_id": job.id,
                "status": JobStatus.COMPLETED.value,
                "message": "Processing completed successfully",
            })
            logger.info("Job %s completed", job.id[:8])

        except asyncio.CancelledError:
            job.status = JobStatus.CANCELLED
            await self.publish_event(job.project_id, {
                "type": "job_cancelled",
                "job_id": job.id,
                "status": JobStatus.CANCELLED.value,
                "message": "Processing cancelled",
            })
            logger.info("Job %s cancelled during execution", job.id[:8])

        except Exception as exc:
            job.status = JobStatus.FAILED
            job.error = str(exc)
            await self.publish_event(job.project_id, {
                "type": "job_failed",
                "job_id": job.id,
                "status": JobStatus.FAILED.value,
                "message": f"Processing failed: {exc}",
                "error": str(exc),
            })
            logger.error("Job %s failed: %s", job.id[:8], exc, exc_info=True)

        finally:
            job.completed_at = datetime.now(timezone.utc)
            self._tasks.pop(job.id, None)

    async def shutdown(self) -> None:
        """Gracefully cancel all running tasks."""
        logger.info("Shutting down job queue...")
        for task in list(self._tasks.values()):
            if not task.done():
                task.cancel()

        if self._tasks:
            await asyncio.gather(*self._tasks.values(), return_exceptions=True)

        self._tasks.clear()
        self._started = False
        logger.info("Job queue shut down")
