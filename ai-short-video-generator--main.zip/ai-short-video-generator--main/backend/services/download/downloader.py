import asyncio
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional, Any

import yt_dlp

from backend.exceptions import DownloadError
from backend.models.project import VideoMetadata
from backend.services.storage import StorageService

logger = logging.getLogger(__name__)

@dataclass
class DownloadResult:
    video_path: Path
    video_id: str
    metadata: VideoMetadata
    from_cache: bool

class DownloadService:
    """Downloads YouTube videos using yt-dlp with caching."""
    
    def __init__(self, storage: StorageService):
        self.storage = storage

    def extract_video_id(self, url: str) -> str:
        """Extract YouTube video ID from URL."""
        pattern = r"(?:v=|\/)([0-9A-Za-z_-]{11}).*"
        match = re.search(pattern, url)
        if match:
            return match.group(1)
        if len(url) == 11 and re.match(r"^[0-9A-Za-z_-]{11}$", url):
            return url
        raise DownloadError("Could not extract video ID from URL")

    async def get_video_info(self, youtube_url: str) -> VideoMetadata:
        """Get video metadata without downloading."""
        loop = asyncio.get_running_loop()
        ydl_opts: dict[str, Any] = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': True,
        }
        
        cookies_path = Path("/teamspace/studios/this_studio/cookies.txt")
        if not cookies_path.exists():
            cookies_path = Path("cookies.txt").absolute()
        if cookies_path.exists():
            ydl_opts['cookiefile'] = str(cookies_path)

        
        def _extract():
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                return ydl.extract_info(youtube_url, download=False)
                
        try:
            info = await loop.run_in_executor(None, _extract)
        except Exception as e:
            raise DownloadError(f"Failed to fetch video info: {e}") from e
            
        if not info:
            raise DownloadError("Could not extract video info (yt-dlp returned None)")
            

        return VideoMetadata(
            youtube_url=youtube_url,
            video_id=info.get('id', self.extract_video_id(youtube_url)),
            title=info.get('title', 'Unknown Title'),
            duration=float(info.get('duration', 0.0)),
            channel=info.get('uploader', 'Unknown Channel'),
            thumbnail_url=info.get('thumbnail'),
            width=int(info.get('width', 1920)),
            height=int(info.get('height', 1080)),
            fps=float(info.get('fps', 30.0))
        )

    async def download(self, youtube_url: str, on_progress: Optional[Callable[[float], None]] = None) -> DownloadResult:
        """Download video, return DownloadResult with paths and metadata."""
        video_id = self.extract_video_id(youtube_url)
        video_filename = "video.mp4"
        cached_path = self.storage.get_cache_path(video_id, video_filename)
        
        loop = asyncio.get_running_loop()
        
        def progress_hook(d: dict):
            if on_progress is None:
                return
            if d['status'] == 'downloading':
                percent_str = d.get('_percent_str', '').strip()
                percent_str = re.sub(r'\x1b\[[0-9;]*m', '', percent_str)
                if percent_str.endswith('%'):
                    try:
                        percent = float(percent_str[:-1]) / 100.0
                        loop.call_soon_threadsafe(on_progress, percent)
                    except ValueError:
                        pass
                else:
                    downloaded = d.get('downloaded_bytes')
                    total = d.get('total_bytes') or d.get('total_bytes_estimate')
                    if downloaded is not None and total:
                        loop.call_soon_threadsafe(on_progress, downloaded / total)
            elif d['status'] == 'finished':
                loop.call_soon_threadsafe(on_progress, 1.0)

        if self.storage.is_cached(video_id, video_filename):
            logger.info(f"Video {video_id} found in cache, skipping download.")
            metadata = await self.get_video_info(youtube_url)
            return DownloadResult(
                video_path=cached_path,
                video_id=video_id,
                metadata=metadata,
                from_cache=True
            )

        cache_dir = self.storage.get_cache_dir(video_id)
        out_tmpl = str(cache_dir / "video.%(ext)s")

        ydl_opts: dict[str, Any] = {
            'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
            'merge_output_format': 'mp4',
            'outtmpl': out_tmpl,
            'progress_hooks': [progress_hook],
            'quiet': True,
            'no_warnings': True,
        }
        
        cookies_path = Path("/teamspace/studios/this_studio/cookies.txt")
        if not cookies_path.exists():
            cookies_path = Path("cookies.txt").absolute()
        if cookies_path.exists():
            ydl_opts['cookiefile'] = str(cookies_path)


        def _download():
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                return ydl.extract_info(youtube_url, download=True)

        logger.info(f"Downloading video {video_id}...")
        try:
            info = await loop.run_in_executor(None, _download)
        except Exception as e:
            raise DownloadError(f"Failed to download video: {e}") from e
            
        if not info:
            raise DownloadError("Could not extract video info after download (yt-dlp returned None)")
            
        if not cached_path.exists():
            raise DownloadError(f"Download succeeded but file not found at {cached_path}")

        metadata = VideoMetadata(
            youtube_url=youtube_url,
            video_id=info.get('id', video_id),
            title=info.get('title', 'Unknown Title'),
            duration=float(info.get('duration', 0.0)),
            channel=info.get('uploader', 'Unknown Channel'),
            thumbnail_url=info.get('thumbnail'),
            width=int(info.get('width', 1920)),
            height=int(info.get('height', 1080)),
            fps=float(info.get('fps', 30.0))
        )

        return DownloadResult(
            video_path=cached_path,
            video_id=video_id,
            metadata=metadata,
            from_cache=False
        )
