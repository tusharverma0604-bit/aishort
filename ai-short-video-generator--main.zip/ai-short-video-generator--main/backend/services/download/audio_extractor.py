import asyncio
import logging
import re
from pathlib import Path
from typing import Callable, Optional

from backend.exceptions import FFmpegError
from backend.services.storage import StorageService

logger = logging.getLogger(__name__)

class AudioExtractor:
    """Extracts audio from video files using FFmpeg."""
    
    def __init__(self, storage: StorageService):
        self.storage = storage
        
    async def extract(
        self, 
        video_path: Path, 
        video_id: str, 
        on_progress: Optional[Callable[[float], None]] = None
    ) -> Path:
        """Extract audio from video to WAV format.
        
        - Check cache: if cache/{video_id}/audio.wav exists, skip
        - Extract using FFmpeg subprocess
        - Output: 16kHz mono WAV (optimal for Whisper)
        - Return path to audio file
        """
        audio_filename = "audio.wav"
        
        if self.storage.is_cached(video_id, audio_filename):
            cached_path = self.storage.get_cache_path(video_id, audio_filename)
            logger.info(f"Audio for {video_id} found in cache, skipping extraction.")
            if on_progress:
                on_progress(1.0)
            return cached_path
            
        output_path = self.storage.get_cache_path(video_id, audio_filename)
        logger.info(f"Extracting audio for {video_id} to {output_path}...")
        
        cmd = [
            "ffmpeg",
            "-y",               # overwrite output file
            "-i", str(video_path),
            "-ar", "16000",     # 16kHz
            "-ac", "1",         # mono
            "-af", "aresample=async=1", # ensure audio perfectly aligns with video timestamps
            "-vn",              # no video
            str(output_path)
        ]
        
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            duration = 0.0
            duration_pattern = re.compile(r"Duration: (\d{2}):(\d{2}):(\d{2}\.\d{2})")
            time_pattern = re.compile(r"time=(\d{2}):(\d{2}):(\d{2}\.\d{2})")
            
            while True:
                line = await process.stderr.readline()
                if not line:
                    break
                
                line_str = line.decode('utf-8', errors='replace')
                
                if duration == 0.0:
                    dur_match = duration_pattern.search(line_str)
                    if dur_match:
                        h, m, s = dur_match.groups()
                        duration = float(h) * 3600 + float(m) * 60 + float(s)
                
                if on_progress and duration > 0.0:
                    time_match = time_pattern.search(line_str)
                    if time_match:
                        h, m, s = time_match.groups()
                        current_time = float(h) * 3600 + float(m) * 60 + float(s)
                        progress = min(1.0, current_time / duration)
                        on_progress(progress)
            
            await process.wait()
            
            if process.returncode != 0:
                raise FFmpegError(f"FFmpeg process failed with return code {process.returncode}")
                
            if not output_path.exists():
                raise FFmpegError("FFmpeg extraction finished but output file not found")
                
            if on_progress:
                on_progress(1.0)
                
            return output_path
            
        except Exception as e:
            logger.error(f"Error during audio extraction: {e}")
            if output_path.exists():
                output_path.unlink(missing_ok=True)
            if isinstance(e, FFmpegError):
                raise
            raise FFmpegError(f"Audio extraction failed: {str(e)}") from e
