import logging
import sys
from pathlib import Path

def setup_logging(log_level: str) -> None:
    """
    Configures structured logging for the application with both console and file handlers.
    Outputs to console and to storage/logs/app.log.
    """
    # Convert string level to logging level
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)

    log_format = "%(asctime)s - %(levelname)s - %(name)s - %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"

    handlers = []

    # File handler
    log_dir = Path("./storage/logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    file_handler = logging.FileHandler(log_dir / "app.log")
    file_handler.setFormatter(logging.Formatter(log_format, datefmt=date_format))
    handlers.append(file_handler)

    # Console handler
    try:
        from rich.logging import RichHandler
        console_handler = RichHandler(rich_tracebacks=True, markup=True)
        # RichHandler provides its own formatting, so we use a simpler format
        console_formatter = logging.Formatter("%(name)s - %(message)s")
        console_handler.setFormatter(console_formatter)
        handlers.append(console_handler)
    except ImportError:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(logging.Formatter(log_format, datefmt=date_format))
        handlers.append(console_handler)

    # Configure root logger
    logging.basicConfig(
        level=numeric_level,
        handlers=handlers,
        force=True
    )
