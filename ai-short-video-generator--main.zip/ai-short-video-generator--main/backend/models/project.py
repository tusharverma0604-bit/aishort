from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class ProjectStatus(str, Enum):
    PENDING = "pending"
    DOWNLOADING = "downloading"
    EXTRACTING_AUDIO = "extracting_audio"
    TRANSCRIBING = "transcribing"
    ANALYZING = "analyzing"
    CUTTING = "cutting"
    REFRAMING = "reframing"
    CAPTIONING = "captioning"
    EXPORTING = "exporting"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class StageStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class StageInfo(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    name: str
    status: StageStatus = StageStatus.PENDING
    progress: float = Field(default=0.0, ge=0.0, le=1.0)
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error: str | None = None
    retry_count: int = 0


class VideoMetadata(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    youtube_url: str
    video_id: str
    title: str
    duration: float  # seconds
    channel: str
    thumbnail_url: str | None = None
    width: int
    height: int
    fps: float


class TranscriptWord(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    word: str
    start: float
    end: float
    confidence: float


class TranscriptSegment(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    start: float
    end: float
    text: str
    words: list[TranscriptWord] = Field(default_factory=list)


class Transcript(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    language: str
    segments: list[TranscriptSegment] = Field(default_factory=list)
    full_text: str


class ViralClipCandidate(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    title: str
    reason: str
    score: int = Field(ge=0, le=100)
    start_time: float
    end_time: float
    hook: str
    tags: list[str] = Field(default_factory=list)
    mood: str | None = None
    zoom_start: float | None = None
    zoom_end: float | None = None
    youtube_title: str | None = None
    youtube_description: str | None = None


class ViralClipResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    clips: list[ViralClipCandidate] = Field(default_factory=list)


class ProcessedClip(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    clip_id: str  # e.g. "clip_001"
    candidate: ViralClipCandidate
    source_path: str | None = None
    reframed_path: str | None = None
    captioned_path: str | None = None
    final_path: str | None = None
    thumbnail_path: str | None = None
    duration: float
    caption_style: str
    status: StageStatus = StageStatus.PENDING
    error: str | None = None
    youtube_url: str | None = None


class ProjectSettings(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    caption_style: str = "hormozi"
    reframe_mode: str = "crop"
    language: str | None = None  # e.g. "te" for Telugu, "hi" for Hindi, "en" for English, None for auto-detect
    max_clips: int = 10
    min_clip_score: int = 75
    min_clip_duration: int = 15
    max_clip_duration: int = 60
    auto_reframe: bool = True
    burn_captions: bool = True
    export_fps: int = 60
    export_width: int = 1080
    export_height: int = 1920
    youtube_upload_mode: str = "off"  # "off", "public", "private", "schedule"
    youtube_schedule_start_time: str | None = None  # ISO 8601 string
    youtube_schedule_interval_hours: int = 24
    translate_to_english: bool = False


class Project(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str  # UUID
    status: ProjectStatus = ProjectStatus.PENDING
    settings: ProjectSettings = Field(default_factory=ProjectSettings)
    video_metadata: VideoMetadata | None = None
    transcript: Transcript | None = None
    viral_candidates: list[ViralClipCandidate] = Field(default_factory=list)
    clips: list[ProcessedClip] = Field(default_factory=list)
    stages: list[StageInfo] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)
    error: str | None = None
    cache_dir: str | None = None
