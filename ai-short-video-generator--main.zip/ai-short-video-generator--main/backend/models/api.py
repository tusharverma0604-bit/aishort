from __future__ import annotations

import re

from pydantic import BaseModel, ConfigDict, field_validator

from backend.models.project import (
    ProcessedClip,
    Project,
    ProjectSettings,
    ProjectStatus,
    StageStatus,
)


class CreateProjectRequest(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "youtube_url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                "settings": {
                    "caption_style": "hormozi",
                    "max_clips": 5
                }
            }
        }
    )

    youtube_url: str
    settings: ProjectSettings | None = None

    @field_validator("youtube_url")
    @classmethod
    def validate_youtube_url(cls, v: str) -> str:
        # Matches patterns like youtube.com/watch?v=ID, youtu.be/ID, youtube.com/shorts/ID
        pattern = r"(?:https?://)?(?:www\.)?(?:youtube\.com/(?:watch\?.*v=|shorts/)|youtu\.be/)([a-zA-Z0-9_-]{11})"
        if not re.search(pattern, v):
            raise ValueError("Invalid YouTube URL. Must be a valid youtube.com or youtu.be link.")
        return v


class CreateProjectResponse(BaseModel):
    project_id: str
    status: ProjectStatus


class ProjectStatusResponse(BaseModel):
    project: Project


class ClipListResponse(BaseModel):
    clips: list[ProcessedClip]
    total: int


class PipelineStageUpdate(BaseModel):
    project_id: str
    stage: str
    status: StageStatus
    progress: float
    message: str | None = None


class SystemInfoResponse(BaseModel):
    gpu_device: str
    gpu_available: bool
    ram_total_gb: float
    ram_available_gb: float
    whisper_model: str
    whisper_device: str
    ffmpeg_version: str
    storage_path: str
    llm_provider: str
    llm_model: str


class ErrorResponse(BaseModel):
    error: str
    detail: str | None = None
    stage: str | None = None
