from lightning_sdk import Studio
import sys

print("Connecting to Studio...")
try:
    studio = Studio(name="shortclips-ai", teamspace="hitman")
    studio.start()
    print("Uploading file...")
    studio.upload_file("backend/services/video/auto_reframe.py", "/teamspace/studios/this_studio/backend/services/video/auto_reframe.py")
    print("Upload complete!")
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)
