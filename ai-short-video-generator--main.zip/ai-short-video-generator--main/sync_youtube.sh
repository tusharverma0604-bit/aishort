export PATH="/Library/Frameworks/Python.framework/Versions/3.13/bin:$PATH"

STUDIO_PATH="lit://hitman/deploy-model-project/studios/shortclips-ai"

lightning studio cp "backend/config.py" "$STUDIO_PATH/backend/config.py"
lightning studio cp "backend/main.py" "$STUDIO_PATH/backend/main.py"
lightning studio cp "backend/models/project.py" "$STUDIO_PATH/backend/models/project.py"
lightning studio cp "backend/pipeline/orchestrator.py" "$STUDIO_PATH/backend/pipeline/orchestrator.py"
lightning studio cp "backend/services/llm/prompts/viral_moments.txt" "$STUDIO_PATH/backend/services/llm/prompts/viral_moments.txt"
lightning studio cp "backend/services/llm/providers/__init__.py" "$STUDIO_PATH/backend/services/llm/providers/__init__.py"
lightning studio cp "backend/services/llm/providers/gemini.py" "$STUDIO_PATH/backend/services/llm/providers/gemini.py"

lightning studio rm "$STUDIO_PATH/backend/services/llm/providers/omnirouter.py" || true

lightning studio cp "backend/api/routes/youtube.py" "$STUDIO_PATH/backend/api/routes/youtube.py"
lightning studio cp "backend/services/youtube_uploader.py" "$STUDIO_PATH/backend/services/youtube_uploader.py"

lightning studio cp "frontend/src/components/SettingsPanel.tsx" "$STUDIO_PATH/frontend/src/components/SettingsPanel.tsx"
lightning studio cp "frontend/src/lib/api.ts" "$STUDIO_PATH/frontend/src/lib/api.ts"
lightning studio cp "frontend/src/lib/types.ts" "$STUDIO_PATH/frontend/src/lib/types.ts"
lightning studio cp "start.sh" "$STUDIO_PATH/start.sh"

echo "Sync complete!"
