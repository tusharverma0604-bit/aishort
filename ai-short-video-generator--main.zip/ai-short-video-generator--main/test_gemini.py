import asyncio
import os
import json
from backend.services.llm.providers.gemini import GeminiProvider
from backend.models.project import ViralClipResponse

async def main():
    api_key = os.environ.get("GEMINI_API_KEY", os.environ.get("GOOGLE_API_KEY"))
    if not api_key:
        print("NO API KEY")
        return
    provider = GeminiProvider(api_key=api_key, model="gemini-3.5-flash")
    
    prompt = "Return 5 long dummy clips that have at least 500 characters each."
    messages = [
        {"role": "system", "content": "You are a helpful assistant that strictly outputs JSON."},
        {"role": "user", "content": prompt}
    ]
    
    try:
        res = await provider.chat_completion(messages, response_schema=ViralClipResponse)
        print("SUCCESS!")
        print(len(res))
    except Exception as e:
        print("FAILED!")
        print(e)
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
