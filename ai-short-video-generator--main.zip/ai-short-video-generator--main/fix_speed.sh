#!/bin/bash
# Clean up ComfyUI background scripts and optimize speed
set -e

echo "🚀 Creating speed optimization routes..."

cd /teamspace/studios/this_studio/frontend

# 1. Create directories
mkdir -p public
mkdir -p src/app/api/history
mkdir -p src/app/api/queue
mkdir -p "src/app/api/manager/[...path]"
mkdir -p "src/app/manager/[...path]"
mkdir -p "src/app/api/experiment/[...path]"

# 2. Create self-destructing Service Worker
cat << 'EOF' > public/sw.js
self.addEventListener('install', (e) => {
  self.skipWaiting();
});
self.addEventListener('activate', (e) => {
  e.waitUntil(
    self.registration.unregister().then(() => {
      console.log('Old ComfyUI SW unregistered');
    })
  );
});
EOF

# 3. Create ultra-fast dummy route handlers
ROUTE_CODE="export async function GET() { return new Response(null, { status: 204 }); }; export async function POST() { return new Response(null, { status: 204 }); };"

echo "$ROUTE_CODE" > src/app/api/history/route.ts
echo "$ROUTE_CODE" > src/app/api/queue/route.ts
echo "$ROUTE_CODE" > "src/app/api/manager/[...path]/route.ts"
echo "$ROUTE_CODE" > "src/app/manager/[...path]/route.ts"
echo "$ROUTE_CODE" > "src/app/api/experiment/[...path]/route.ts"

echo "✅ Speed optimization routes created successfully!"
