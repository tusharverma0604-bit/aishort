# 🚀 GPU Deployment & Setup Guide

The AI Short Video Generator uses heavy AI models like **Whisper (large-v3)** for transcription and **MediaPipe** for face-tracking. 

While you *can* run this on a standard laptop CPU, video generation will be very slow (taking 15-30 minutes per video). **For fast, production-level generation (1-3 minutes per video), you need an NVIDIA GPU.**

If you don't have a powerful PC, don't worry! Here is a step-by-step guide to setting up the backend on popular Cloud GPU providers.

---

## ⚡ Option 1: Lightning AI Studio (Highly Recommended)
[Lightning AI](https://lightning.ai/) offers Cloud Studios that feel exactly like VS Code in your browser. It is incredibly easy to set up and offers free GPU credits for new users. This is the exact environment this project was built on!

### Step-by-Step Setup:
1. Go to [Lightning AI](https://lightning.ai/) and create a free account.
2. Click **"New Studio"** -> Select the **"PyTorch"** or **"Blank"** template.
3. In the top right corner of your new Studio, change the hardware from CPU to a **T4 GPU** or **L4 GPU**.
4. Open the terminal at the bottom of the Studio and clone the repository:
   ```bash
   git clone https://github.com/your-username/ai-short-video-generator-.git
   cd ai-short-video-generator-
   ```
5. Install the required system packages (FFmpeg):
   ```bash
   sudo apt update
   sudo apt install -y ffmpeg
   ```
6. Install the Python requirements:
   ```bash
   pip install -r requirements.txt
   ```
7. Start the backend server:
   ```bash
   python backend/main.py
   ```
8. **Connect your Frontend:** Lightning AI will give you a public URL for port `8001`. You can run your Next.js frontend locally on your laptop, and just point the API calls to your Lightning Studio URL!

---

## ☁️ Option 2: Google Colab (Best Free Option)
[Google Colab](https://colab.research.google.com/) provides free access to T4 GPUs. It is slightly more manual since it's a notebook environment, but it costs $0.

### Step-by-Step Setup:
1. Go to Google Colab and create a New Notebook.
2. Go to **Runtime** -> **Change runtime type** -> Select **T4 GPU**.
3. Create a code block and run the following commands to clone the repo and install FFmpeg:
   ```python
   !git clone https://github.com/your-username/ai-short-video-generator-.git
   %cd ai-short-video-generator-
   !sudo apt update && sudo apt install -y ffmpeg
   !pip install -r requirements.txt
   ```
4. To make the FastAPI server accessible to the internet, you can use `localtunnel` or `ngrok`. Run this block:
   ```python
   !npm install -g localtunnel
   import subprocess
   # Start backend in the background
   subprocess.Popen(["python", "backend/main.py"])
   # Expose port 8001
   !lt --port 8001
   ```
5. Copy the `localtunnel` URL and use it in your frontend configuration.

---

## 🌩️ Option 3: RunPod / Vast.ai (Best for Scaling)
If you want to run this 24/7 as a SaaS or for a large automation channel, [RunPod](https://runpod.io) or [Vast.ai](https://vast.ai) are the cheapest ways to rent dedicated GPUs (usually around $0.20/hour for an RTX 3090 or 4090).

### Step-by-Step Setup (RunPod):
1. Go to RunPod and deploy a new **Pod**.
2. Select an RTX 3090 or 4090.
3. For the template, select the official **RunPod PyTorch** template.
4. Expose TCP ports `8001` (Backend) and `3000` (Frontend) in the Pod settings before launching.
5. Connect to the Pod via the Web Terminal or SSH.
6. Run the standard setup:
   ```bash
   apt update && apt install -y ffmpeg
   git clone https://github.com/your-username/ai-short-video-generator-.git
   cd ai-short-video-generator-
   pip install -r requirements.txt
   cd frontend && npm install && cd ..
   ```
7. Run the start script to launch both frontend and backend:
   ```bash
   bash start.sh
   ```
8. Access your application using the public IP provided by RunPod!

---

## 💻 Option 4: Local Setup (Windows/Mac/Linux)
If you have a gaming PC or a Mac with an M1/M2/M3 chip, you can run this locally.

### Windows (NVIDIA GPU)
1. Install [Python 3.10+](https://www.python.org/downloads/) and [Node.js](https://nodejs.org/).
2. Download **FFmpeg** from [gyan.dev](https://www.gyan.dev/ffmpeg/builds/) and add it to your Windows System PATH.
3. Install **CUDA Toolkit** from NVIDIA's website to ensure hardware acceleration works.
4. Clone the repo and run `pip install -r requirements.txt`. (The code will automatically detect your CUDA GPU).

### macOS (Apple Silicon M1/M2/M3)
While Apple Silicon does not have CUDA, the libraries (like PyTorch and Whisper) will automatically fall back to CPU or use the Metal Performance Shaders (MPS) where applicable. Video processing will be slower than a dedicated NVIDIA GPU, but still functional!
1. Install Homebrew: `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`
2. Install FFmpeg: `brew install ffmpeg`
3. Run the setup via `start.sh`.
