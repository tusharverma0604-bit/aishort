# 🎬 AI Short Video Generator

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/riyazpattan)

An open-source, fully automated tool that converts long-form YouTube videos into highly engaging, viral short-form content (TikTok, YouTube Shorts, Instagram Reels).

Powered by state-of-the-art AI, this tool automatically downloads videos, transcribes them, identifies the most viral moments using LLMs (Gemini, OpenAI, Claude), reframes the video to a vertical 9:16 aspect ratio (with intelligent face tracking), and can even upload them directly back to YouTube!

## ✨ Features

- **📺 YouTube Integration**: Instantly download and process any public YouTube video.
- **🗣️ Precision Transcription**: Uses Whisper (large-v3) for lightning-fast and highly accurate transcription.
- **🧠 Viral Moment Detection**: Leverages advanced LLMs (Gemini, OpenAI, Claude, or custom providers) to analyze transcripts and identify high-retention, viral clips based on hook quality and narrative structure.
- **🎯 Smart Auto-Reframing**: 
  - **Smart Crop (Face Tracking)**: Uses MediaPipe Face Mesh to dynamically track the active speaker and keep them perfectly centered in the vertical frame.
  - **Fit (Blurred Background)**: Scales the video to fit the frame while adding a beautiful, blurred version of the video in the background.
  - **Fit (Black Bars)**: Scales the video perfectly with standard black bars.
- **🚀 Direct YouTube Upload**: Built-in OAuth 2.0 integration to upload generated shorts straight to your YouTube channel directly from the dashboard.
- **🎨 Beautiful UI**: A stunning, high-contrast, modern Next.js frontend inspired by premium SaaS platforms.

## 🛠️ Architecture

- **Backend**: FastAPI (Python), FFmpeg, faster-whisper, MediaPipe, Google GenAI SDK
- **Frontend**: Next.js 14, React, Vanilla CSS (Custom Design System)
- **Infrastructure**: Designed to run efficiently on Cloud GPUs (e.g., Lightning AI Studio, AWS EC2, or local machines with NVIDIA GPUs).

## 🚀 Getting Started

> **[IMPORTANT]**
> Video generation relies heavily on an NVIDIA GPU for fast Whisper transcription and FFmpeg hardware acceleration. While it *can* run on a CPU, it will be very slow.
> 
> **👉 Read the [GPU Deployment & Setup Guide](DEPLOYMENT.md) for step-by-step instructions on running this project for free/cheap on Lightning AI, Google Colab, or RunPod.**

### Prerequisites

- **Python 3.10+** (with pip)
- **Node.js 18+** (with npm)
- **FFmpeg** installed and added to your system PATH.
- **NVIDIA GPU** (Highly recommended for fast Whisper transcription and FFmpeg hardware acceleration).

### 1. Clone the repository

```bash
git clone https://github.com/yourusername/ai-short-video-generator.git
cd ai-short-video-generator
```

### 2. Backend Setup

```bash
# Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install
```

### 4. Running the Application

You can start both the backend and frontend simultaneously by running the startup script from the root directory:

```bash
bash start.sh
```

- The frontend will be available at `http://localhost:3000`
- The backend API will be available at `http://localhost:8001`

### 5. Configuration

When you first open the application, you can dive straight in! Before generating videos or connecting to YouTube, you will be prompted to configure your settings via the beautiful **Global Settings** UI:
- Add your preferred **AI API Key** (Gemini, OpenAI, Claude, etc.).
- Add your **YouTube Client ID and Secret** (for direct uploads). 
*Note: These are securely saved locally on your machine in the `storage/` directory.*

## 💖 Support this Project

If this tool has helped you save time or build a viral channel, consider supporting the development! Every coffee helps keep the project open-source and frequently updated.

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/riyazpattan)

## 🤝 Contributing

Contributions are welcome! If you'd like to help improve this project, please:
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.
